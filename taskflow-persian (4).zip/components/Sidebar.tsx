import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { LayoutDashboard, MessageSquare, FolderKanban, Users, Calendar, StickyNote, BarChart2, PieChart, Hash } from 'lucide-react';

export const Sidebar: React.FC<{ isOpen: boolean }> = ({ isOpen }) => {
  const location = useLocation();

  const menuItems = [
    { name: 'داشبرد من', icon: LayoutDashboard, path: '/' },
    { name: 'کانال‌ها', icon: Hash, path: '/channels' },
    { name: 'پیام‌ها', icon: MessageSquare, path: '/messages' },
    { name: 'پروژه‌ها', icon: FolderKanban, path: '/projects' },
    { name: 'جلسات', icon: Calendar, path: '/meetings' },
    { name: 'یادداشت‌ها', icon: StickyNote, path: '/notes' },
    { name: 'اعضا', icon: Users, path: '/users' },
    { name: 'گزارش اعضا', icon: PieChart, path: '/reports/users' },
    { name: 'گزارش پروژه‌ها', icon: BarChart2, path: '/reports/projects' },
  ];

  if (!isOpen) return null;

  return (
    <aside className="w-64 bg-slate-900 text-white flex-shrink-0 min-h-screen shadow-xl transition-all duration-300">
      <div className="p-6 border-b border-slate-700 flex items-center justify-center">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
          تسک‌فلو
        </h1>
      </div>
      <nav className="p-4 space-y-2">
        {menuItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center space-x-3 space-x-reverse px-4 py-3 rounded-xl transition-colors ${
                isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <item.icon size={20} />
              <span className="font-medium">{item.name}</span>
            </Link>
          );
        })}
      </nav>
      
      <div className="absolute bottom-0 w-full p-4 border-t border-slate-800">
        <div className="bg-slate-800 rounded-lg p-3 text-center text-xs text-slate-500">
          نسخه ۱.۰.۰
          <br />
          پشتیبانی: support@taskflow.ir
        </div>
      </div>
    </aside>
  );
};