import React, { useState } from 'react';
import { Plus, Bell, Search, Mail, Menu, StickyNote, User as UserIcon, LogOut, Settings } from 'lucide-react';
import { User } from '../types';

interface TopBarProps {
  user: User;
  toggleSidebar: () => void;
  onLogout: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ user, toggleSidebar, onLogout }) => {
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <header className="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-6 sticky top-0 z-20 shadow-sm">
      {/* Right Side (In RTL this is visually Right) - Hamburger & Title */}
      <div className="flex items-center gap-4">
        <button 
          onClick={toggleSidebar}
          className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition-colors"
        >
          <Menu size={24} />
        </button>
        {/* Breadcrumbs or Page Title could go here */}
      </div>

      {/* Left Side (In RTL this is visually Left) - Quick Actions */}
      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="relative hidden md:block group">
          <input
            type="text"
            placeholder="جستجو..."
            className="w-64 bg-slate-100 text-slate-700 text-sm rounded-full px-4 py-2 pl-10 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all"
          />
          <Search size={16} className="absolute left-3 top-2.5 text-slate-400" />
        </div>

        <div className="h-6 w-px bg-slate-300 mx-2 hidden md:block"></div>

        {/* Quick Actions */}
        <button className="p-2 text-slate-500 hover:bg-blue-50 hover:text-blue-600 rounded-full transition-colors tooltip" title="ایجاد وظیفه جدید">
          <Plus size={20} />
        </button>
        <button className="p-2 text-slate-500 hover:bg-yellow-50 hover:text-yellow-600 rounded-full transition-colors tooltip" title="یادداشت جدید">
          <StickyNote size={20} />
        </button>
        <button className="p-2 text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 rounded-full transition-colors tooltip" title="ارسال پیام">
          <Mail size={20} />
        </button>
        
        <div className="relative">
             <button className="p-2 text-slate-500 hover:bg-red-50 hover:text-red-600 rounded-full transition-colors relative">
                <Bell size={20} />
                <span className="absolute top-1 right-1 h-2.5 w-2.5 bg-red-500 rounded-full border border-white"></span>
            </button>
        </div>

        {/* User Profile */}
        <div className="relative mr-4">
          <button 
            onClick={() => setShowUserMenu(!showUserMenu)}
            className="flex items-center gap-2 hover:bg-slate-100 rounded-full p-1 pr-2 transition-colors border border-slate-200"
          >
            <span className="text-sm font-medium text-slate-700 hidden md:block">{user.name}</span>
            <img 
              src={user.avatar} 
              alt={user.name} 
              className="w-8 h-8 rounded-full object-cover border border-white shadow-sm" 
            />
          </button>

          {showUserMenu && (
            <div className="absolute top-full left-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-100 py-2 animate-in fade-in slide-in-from-top-2">
              <div className="px-4 py-2 border-b border-slate-100 mb-1">
                <p className="text-sm font-bold text-slate-800">{user.name}</p>
                <p className="text-xs text-slate-500">{user.email}</p>
              </div>
              <button className="w-full text-right px-4 py-2 text-sm text-slate-600 hover:bg-slate-50 hover:text-blue-600 flex items-center gap-2">
                <UserIcon size={16} /> پروفایل
              </button>
              <button className="w-full text-right px-4 py-2 text-sm text-slate-600 hover:bg-slate-50 hover:text-blue-600 flex items-center gap-2">
                <Settings size={16} /> تنظیمات
              </button>
              <button 
                onClick={onLogout}
                className="w-full text-right px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2"
              >
                <LogOut size={16} /> خروج
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};