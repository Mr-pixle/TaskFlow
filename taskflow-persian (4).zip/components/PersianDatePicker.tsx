import React, { useState, useRef, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Calendar as CalendarIcon } from 'lucide-react';
import { toGregorian, toJalaali, jalaaliMonthLength } from 'jalaali-js';

interface PersianDatePickerProps {
  value: string; // Format: "1403/01/15"
  onChange: (date: string) => void;
  label?: string;
  className?: string;
}

const MONTH_NAMES = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
];

const WEEK_DAYS = ['ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج'];

export const PersianDatePicker: React.FC<PersianDatePickerProps> = ({ value, onChange, label, className }) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Parse initial value or default to today
  const getInitialDate = () => {
    if (value) {
      const parts = value.split('/');
      if (parts.length === 3) {
        const y = parseInt(parts[0]);
        const m = parseInt(parts[1]);
        const d = parseInt(parts[2]);
        if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
          return { y, m, d };
        }
      }
    }
    const today = new Date();
    const j = toJalaali(today.getFullYear(), today.getMonth() + 1, today.getDate());
    return { y: j.jy, m: j.jm, d: j.jd };
  };

  const [viewDate, setViewDate] = useState(getInitialDate()); // For navigation
  const [selectedDate, setSelectedDate] = useState(getInitialDate()); // For selection

  // Update internal state when prop changes
  useEffect(() => {
    if (value) {
        const parts = value.split('/');
        if (parts.length === 3) {
            const y = parseInt(parts[0]);
            const m = parseInt(parts[1]);
            const d = parseInt(parts[2]);
            if (!isNaN(y) && !isNaN(m) && !isNaN(d)) {
                setSelectedDate({ y, m, d });
            }
        }
    }
  }, [value]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const changeMonth = (delta: number) => {
    let newM = viewDate.m + delta;
    let newY = viewDate.y;

    if (newM > 12) {
      newM = 1;
      newY++;
    } else if (newM < 1) {
      newM = 12;
      newY--;
    }
    setViewDate({ ...viewDate, m: newM, y: newY });
  };

  const handleDayClick = (day: number) => {
    const newDateStr = `${viewDate.y}/${String(viewDate.m).padStart(2, '0')}/${String(day).padStart(2, '0')}`;
    setSelectedDate({ y: viewDate.y, m: viewDate.m, d: day });
    onChange(newDateStr);
    setIsOpen(false);
  };

  // Calculate calendar grid
  const monthLength = jalaaliMonthLength(viewDate.y, viewDate.m);
  const startDayGregorian = toGregorian(viewDate.y, viewDate.m, 1);
  const startDayDate = new Date(startDayGregorian.gy, startDayGregorian.gm - 1, startDayGregorian.gd);
  const startDayOfWeek = (startDayDate.getDay() + 1) % 7; // Map to Persian week (Sat=0)

  const renderDays = () => {
    const days = [];
    // Empty slots
    for (let i = 0; i < startDayOfWeek; i++) {
      days.push(<div key={`empty-${i}`} className="w-8 h-8"></div>);
    }
    // Days
    for (let i = 1; i <= monthLength; i++) {
      const isSelected = selectedDate.y === viewDate.y && selectedDate.m === viewDate.m && selectedDate.d === i;
      
      days.push(
        <button
          key={i}
          onClick={() => handleDayClick(i)}
          className={`w-8 h-8 text-sm rounded-full flex items-center justify-center transition-colors ${
            isSelected
              ? 'bg-blue-600 text-white shadow-md'
              : 'text-slate-700 hover:bg-slate-100'
          }`}
        >
          {i.toLocaleString('fa-IR')}
        </button>
      );
    }
    return days;
  };

  return (
    <div className="relative" ref={containerRef}>
      {label && <span className="text-xs text-slate-500 block mb-1">{label}</span>}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={className || "flex items-center gap-2 bg-slate-50 border border-slate-200 hover:border-blue-400 px-3 py-1.5 rounded-lg text-sm text-slate-700 transition-all focus:outline-none focus:ring-2 focus:ring-blue-100 min-w-[120px]"}
      >
        <CalendarIcon size={14} className="text-slate-400" />
        <span className="truncate">{value || 'انتخاب تاریخ'}</span>
      </button>

      {isOpen && (
        <div className="absolute top-full right-0 mt-2 bg-white border border-slate-200 rounded-xl shadow-xl z-50 w-64 p-4 animate-in fade-in zoom-in-95 duration-200">
          {/* Header */}
          <div className="flex justify-between items-center mb-4">
            <button onClick={() => changeMonth(-1)} className="p-1 hover:bg-slate-100 rounded-lg text-slate-500">
              <ChevronRight size={16} /> {/* RTL: Right is previous visually for logic */}
            </button>
            <span className="font-bold text-slate-800 text-sm">
              {MONTH_NAMES[viewDate.m - 1]} {viewDate.y.toLocaleString('fa-IR').replace(/٬/g, '')}
            </span>
            <button onClick={() => changeMonth(1)} className="p-1 hover:bg-slate-100 rounded-lg text-slate-500">
              <ChevronLeft size={16} />
            </button>
          </div>

          {/* Week Days */}
          <div className="grid grid-cols-7 mb-2">
            {WEEK_DAYS.map((d) => (
              <div key={d} className="text-center text-xs text-slate-400 font-medium">
                {d}
              </div>
            ))}
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-y-1 justify-items-center">
            {renderDays()}
          </div>
          
          <div className="mt-3 pt-3 border-t border-slate-100 flex justify-center">
              <button 
                onClick={() => {
                   const today = new Date();
                   const jToday = toJalaali(today.getFullYear(), today.getMonth() + 1, today.getDate());
                   const str = `${jToday.jy}/${String(jToday.jm).padStart(2, '0')}/${String(jToday.jd).padStart(2, '0')}`;
                   onChange(str);
                   setViewDate({y: jToday.jy, m: jToday.jm, d: jToday.jd});
                   setIsOpen(false);
                }}
                className="text-xs text-blue-600 hover:text-blue-700 font-medium"
              >
                  برو به امروز
              </button>
          </div>
        </div>
      )}
    </div>
  );
};