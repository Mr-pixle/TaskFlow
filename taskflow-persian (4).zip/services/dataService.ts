
import { MOCK_CHANNELS, MOCK_MEETINGS, MOCK_MESSAGES, MOCK_NOTES, MOCK_PROJECTS, MOCK_TASKS, MOCK_USERS } from '../constants';
import { Project, Task, User, Message, Channel, Meeting, Note } from '../types';

let tasks = [...MOCK_TASKS];
let projects = [...MOCK_PROJECTS];
let users = [...MOCK_USERS];
let messages = [...MOCK_MESSAGES];
let channels = [...MOCK_CHANNELS];
let meetings = [...MOCK_MEETINGS];
let notes = [...MOCK_NOTES];

export const DataService = {
  getTasks: () => tasks,
  // Fix: Added getTasksByUserId method to resolve the error in Dashboard.tsx
  getTasksByUserId: (userId: string) => tasks.filter(t => t.assignees.includes(userId)),
  addTask: (task: Task) => { tasks = [...tasks, task]; return task; },
  updateTask: (updatedTask: Task) => { tasks = tasks.map(t => t.id === updatedTask.id ? updatedTask : t); return updatedTask; },
  
  getProjects: () => projects,
  addProject: (project: Project) => { projects = [...projects, project]; return project; },
  updateProject: (updatedProject: Project) => { 
    projects = projects.map(p => p.id === updatedProject.id ? updatedProject : p); 
    return updatedProject; 
  },
  
  getUsers: () => users,
  getMessages: () => messages,
  
  getChannels: () => channels,
  addChannel: (channel: Channel) => { channels = [...channels, channel]; return channel; },
  updateChannel: (updatedChannel: Channel) => {
    channels = channels.map(c => c.id === updatedChannel.id ? updatedChannel : c);
    return updatedChannel;
  },
  
  getMeetings: () => meetings,
  getNotes: () => notes,
  // Fix: Completed the truncated addNote function and ensured it returns the added Note to resolve the error in Notes.tsx
  addNote: (note: Note) => { notes = [...notes, note]; return note; },
};
