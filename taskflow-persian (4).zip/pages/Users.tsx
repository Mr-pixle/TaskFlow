import React from 'react';
import { DataService } from '../services/dataService';
import { MoreVertical, Mail, Shield, Trash2, Edit } from 'lucide-react';

export const Users: React.FC = () => {
  const users = DataService.getUsers();

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">اعضای سازمان</h1>
          <p className="text-slate-500 mt-1">مدیریت دسترسی‌ها و نقش‌های کاربری</p>
        </div>
        <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-xl font-medium shadow-lg shadow-blue-200 transition-all">
          افزودن عضو جدید
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th className="text-right px-6 py-4 text-sm font-semibold text-slate-600">کاربر</th>
              <th className="text-right px-6 py-4 text-sm font-semibold text-slate-600">نقش</th>
              <th className="text-right px-6 py-4 text-sm font-semibold text-slate-600">ایمیل</th>
              <th className="text-right px-6 py-4 text-sm font-semibold text-slate-600">وضعیت</th>
              <th className="px-6 py-4"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map(user => (
              <tr key={user.id} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <img src={user.avatar} className="w-10 h-10 rounded-full object-cover border border-slate-100" alt={user.name} />
                    <div className="font-medium text-slate-800">{user.name}</div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <Shield size={16} className="text-slate-400" />
                    <span className={`text-sm px-2 py-0.5 rounded-md ${
                      user.role === 'Admin' ? 'bg-purple-100 text-purple-700' : 'bg-slate-100 text-slate-600'
                    }`}>
                      {user.role}
                    </span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2 text-slate-500 text-sm">
                    <Mail size={16} />
                    {user.email}
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-green-50 text-green-700">
                    <span className="w-1.5 h-1.5 rounded-full bg-green-500"></span>
                    فعال
                  </span>
                </td>
                <td className="px-6 py-4 text-left">
                  <div className="flex items-center justify-end gap-2">
                    <button className="p-2 text-slate-400 hover:bg-blue-50 hover:text-blue-600 rounded-lg transition-colors">
                      <Edit size={18} />
                    </button>
                    <button className="p-2 text-slate-400 hover:bg-red-50 hover:text-red-600 rounded-lg transition-colors">
                      <Trash2 size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};