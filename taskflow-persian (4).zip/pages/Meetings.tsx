import React, { useState } from 'react';
import { DataService } from '../services/dataService';
import { Calendar as CalendarIcon, Clock, Users, Plus, Video, MapPin, MoreHorizontal, CheckCircle2, XCircle } from 'lucide-react';
import { PersianDatePicker } from '../components/PersianDatePicker';
import { Meeting } from '../types';

export const Meetings: React.FC = () => {
  const [meetings, setMeetings] = useState(DataService.getMeetings());
  const users = DataService.getUsers();
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const [newMeeting, setNewMeeting] = useState<Partial<Meeting>>({
      title: '', date: '', startTime: '', endTime: '', participants: []
  });

  const handleCreateMeeting = () => {
      if(!newMeeting.title || !newMeeting.date) return;
      
      const created: Meeting = {
          id: `mt-${Date.now()}`,
          title: newMeeting.title || 'جلسه جدید',
          date: newMeeting.date || '',
          startTime: newMeeting.startTime || '10:00',
          endTime: newMeeting.endTime || '11:00',
          participants: newMeeting.participants || [],
          status: 'Scheduled'
      };
      
      // In a real app, update DataService
      setMeetings([...meetings, created]);
      setIsModalOpen(false);
      setNewMeeting({ title: '', date: '', startTime: '', endTime: '', participants: [] });
  };

  const toggleParticipant = (userId: string) => {
      const current = newMeeting.participants || [];
      if(current.includes(userId)) {
          setNewMeeting({...newMeeting, participants: current.filter(id => id !== userId)});
      } else {
          setNewMeeting({...newMeeting, participants: [...current, userId]});
      }
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">جلسات</h1>
          <p className="text-slate-500 mt-1">مدیریت و زمان‌بندی جلسات کاری</p>
        </div>
        <button onClick={() => setIsModalOpen(true)} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-xl font-medium shadow-lg shadow-blue-200 transition-all flex items-center gap-2">
          <Plus size={20} />
          جلسه جدید
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {meetings.map(meeting => {
               const isCompleted = meeting.status === 'Completed';
               return (
                   <div key={meeting.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm hover:shadow-md transition-all relative group">
                       <button className="absolute top-4 left-4 text-slate-400 hover:text-slate-600"><MoreHorizontal size={20}/></button>
                       
                       <div className="flex items-start gap-4 mb-4">
                           <div className={`p-3 rounded-xl text-center min-w-[70px] ${isCompleted ? 'bg-slate-100 text-slate-500' : 'bg-blue-50 text-blue-600'}`}>
                               <span className="block text-sm font-medium opacity-80">{meeting.date.split('/')[1]}</span>
                               <span className="block text-2xl font-bold">{meeting.date.split('/')[2]}</span>
                           </div>
                           <div>
                               <h3 className={`font-bold text-lg ${isCompleted ? 'text-slate-500 line-through' : 'text-slate-800'}`}>{meeting.title}</h3>
                               <div className="flex items-center gap-2 text-sm text-slate-500 mt-1">
                                   <Clock size={14} />
                                   {meeting.startTime} - {meeting.endTime}
                               </div>
                           </div>
                       </div>

                       <div className="flex items-center gap-2 mb-4 text-sm text-slate-600">
                           <Video size={16} className="text-slate-400" />
                           <span>گوگل میت</span>
                       </div>

                       <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                           <div className="flex -space-x-2 space-x-reverse">
                               {meeting.participants.map(pid => {
                                   const u = users.find(user => user.id === pid);
                                   return <img key={pid} src={u?.avatar} className="w-8 h-8 rounded-full border-2 border-white" title={u?.name} />;
                               })}
                           </div>
                           <div className="flex gap-2">
                               {meeting.status === 'Scheduled' && (
                                   <button className="p-2 bg-green-50 text-green-600 rounded-lg hover:bg-green-100 transition-colors" title="انجام شد">
                                       <CheckCircle2 size={18} />
                                   </button>
                               )}
                               <button className="p-2 bg-red-50 text-red-600 rounded-lg hover:bg-red-100 transition-colors" title="لغو جلسه">
                                   <XCircle size={18} />
                               </button>
                           </div>
                       </div>
                   </div>
               );
          })}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in">
           <div className="bg-white rounded-2xl w-full max-w-lg p-6 shadow-2xl">
               <h2 className="text-xl font-bold text-slate-800 mb-6">زمان‌بندی جلسه جدید</h2>
               <div className="space-y-4">
                   <div>
                       <label className="block text-sm font-medium text-slate-700 mb-1">عنوان جلسه</label>
                       <input className="w-full border border-slate-200 rounded-lg p-2.5 focus:ring-2 focus:ring-blue-100 focus:border-blue-400 outline-none transition-all" 
                            value={newMeeting.title} onChange={e => setNewMeeting({...newMeeting, title: e.target.value})} placeholder="مثلا: بررسی هفتگی" />
                   </div>
                   
                   <div className="grid grid-cols-2 gap-4">
                       <div>
                           <label className="block text-sm font-medium text-slate-700 mb-1">تاریخ</label>
                           <PersianDatePicker value={newMeeting.date || ''} onChange={d => setNewMeeting({...newMeeting, date: d})} className="w-full justify-between" />
                       </div>
                       <div className="flex gap-2">
                           <div className="flex-1">
                               <label className="block text-sm font-medium text-slate-700 mb-1">شروع</label>
                               <input type="time" className="w-full border border-slate-200 rounded-lg p-2.5 text-center ltr" value={newMeeting.startTime} onChange={e=>setNewMeeting({...newMeeting, startTime: e.target.value})} />
                           </div>
                           <div className="flex-1">
                               <label className="block text-sm font-medium text-slate-700 mb-1">پایان</label>
                               <input type="time" className="w-full border border-slate-200 rounded-lg p-2.5 text-center ltr" value={newMeeting.endTime} onChange={e=>setNewMeeting({...newMeeting, endTime: e.target.value})} />
                           </div>
                       </div>
                   </div>

                   <div>
                       <label className="block text-sm font-medium text-slate-700 mb-2">شرکت‌کنندگان</label>
                       <div className="flex flex-wrap gap-2">
                           {users.map(u => {
                               const selected = newMeeting.participants?.includes(u.id);
                               return (
                                   <button key={u.id} onClick={() => toggleParticipant(u.id)} className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-sm transition-all ${selected ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                                       <img src={u.avatar} className="w-5 h-5 rounded-full" />
                                       {u.name}
                                   </button>
                               )
                           })}
                       </div>
                   </div>
               </div>
               
               <div className="mt-8 flex justify-end gap-3">
                   <button onClick={() => setIsModalOpen(false)} className="px-5 py-2.5 text-slate-500 hover:bg-slate-100 rounded-xl transition-colors">انصراف</button>
                   <button onClick={handleCreateMeeting} className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl shadow-lg shadow-blue-200 transition-colors">ثبت جلسه</button>
               </div>
           </div>
        </div>
      )}
    </div>
  );
};