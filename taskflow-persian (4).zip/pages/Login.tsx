import React, { useState } from 'react';
import { Eye, EyeOff, Lock, Mail, CheckCircle, ArrowRight } from 'lucide-react';

interface LoginProps {
  onLogin: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 800);
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative bg-[#0f172a] overflow-hidden font-sans">
      {/* Abstract Background Shapes */}
      <div className="absolute top-[-20%] right-[-10%] w-[600px] h-[600px] bg-blue-600/20 rounded-full blur-[120px] animate-pulse"></div>
      <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-purple-600/20 rounded-full blur-[100px] animate-pulse delay-1000"></div>

      <div className="w-full max-w-5xl grid grid-cols-1 md:grid-cols-2 bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl shadow-2xl overflow-hidden relative z-10 m-4">
        
        {/* Left Side: Branding (Hidden on mobile) */}
        <div className="hidden md:flex flex-col justify-center p-12 bg-gradient-to-br from-blue-600/90 to-purple-700/90 text-white relative">
          <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
          <div className="relative z-10">
            <div className="w-16 h-16 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center mb-8 shadow-inner border border-white/20">
              <CheckCircle size={32} className="text-white" />
            </div>
            <h1 className="text-4xl font-bold mb-4">مدیریت هوشمند پروژه‌ها با تسک‌فلو</h1>
            <p className="text-blue-100 leading-relaxed text-lg mb-8">
              تمام کارها، تیم‌ها و اهداف خود را در یک پلتفرم یکپارچه مدیریت کنید. ساده، سریع و قدرتمند.
            </p>
            <div className="flex items-center gap-4 text-sm font-medium">
              <div className="flex -space-x-3 space-x-reverse">
                 {[1,2,3,4].map(i => <div key={i} className="w-10 h-10 rounded-full bg-slate-300 border-2 border-blue-600" style={{backgroundImage: `url(https://picsum.photos/100/100?random=${i})`, backgroundSize: 'cover'}}></div>)}
              </div>
              <span>به جمع +۲۰۰۰ تیم موفق بپیوندید</span>
            </div>
          </div>
        </div>

        {/* Right Side: Login Form */}
        <div className="p-10 md:p-14 flex flex-col justify-center">
          <div className="mb-8">
            <h2 className="text-3xl font-bold text-white mb-2">خوش آمدید 👋</h2>
            <p className="text-slate-400">اطلاعات حساب کاربری خود را وارد کنید</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-300 block">ایمیل</label>
              <div className="relative group">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-800/50 border border-slate-600 rounded-xl px-4 py-3.5 pl-10 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                  placeholder="ali@company.com"
                  required
                />
                <Mail className="absolute left-3 top-3.5 text-slate-500 group-focus-within:text-blue-400 transition-colors" size={20} />
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-sm font-medium text-slate-300">رمز عبور</label>
                <a href="#" className="text-xs text-blue-400 hover:text-blue-300 transition-colors">رمز عبور را فراموش کردید؟</a>
              </div>
              <div className="relative group">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-800/50 border border-slate-600 rounded-xl px-4 py-3.5 pl-10 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-3.5 text-slate-500 hover:text-slate-300 transition-colors"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 rounded-xl shadow-lg shadow-blue-600/30 transition-all transform hover:scale-[1.01] active:scale-[0.99] disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  ورود به حساب
                  <ArrowRight size={20} className="rtl:rotate-180" />
                </>
              )}
            </button>
          </form>

          <div className="mt-8 text-center">
            <p className="text-slate-400 text-sm">
              حساب کاربری ندارید؟ <a href="#" className="text-blue-400 font-bold hover:text-blue-300 transition-colors">ثبت‌نام رایگان</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};