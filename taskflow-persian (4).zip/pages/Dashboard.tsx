import React from 'react';
import { User, Task, Meeting } from '../types';
import { DataService } from '../services/dataService';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { Calendar, CheckCircle, Clock, AlertCircle } from 'lucide-react';

interface DashboardProps {
  user: User;
}

export const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const allTasks = DataService.getTasksByUserId(user.id);
  const meetings = DataService.getMeetings().filter(m => m.participants.includes(user.id));
  
  // Stats Logic
  const overdueTasks = allTasks.filter(t => t.status !== 'Done' && new Date(t.dueDate || '') < new Date()); // Simplistic date check
  const doneTasks = allTasks.filter(t => t.status === 'Done');
  const inProgressTasks = allTasks.filter(t => t.status === 'In Progress');
  const todoTasks = allTasks.filter(t => t.status === 'Todo');

  const chartData = [
    { name: 'انجام شده', value: doneTasks.length, color: '#10b981' },
    { name: 'در حال انجام', value: inProgressTasks.length, color: '#3b82f6' },
    { name: 'انجام نشده', value: todoTasks.length, color: '#f59e0b' },
    { name: 'تاخیر خورده', value: overdueTasks.length, color: '#ef4444' },
  ];

  const barData = [
    { name: 'شنبه', completed: 2, new: 4 },
    { name: 'یک‌شنبه', completed: 5, new: 3 },
    { name: 'دوشنبه', completed: 3, new: 6 },
    { name: 'سه‌شنبه', completed: 6, new: 2 },
    { name: 'چهارشنبه', completed: 4, new: 4 },
  ];

  const StatCard = ({ title, count, icon: Icon, colorClass, bgClass }: any) => (
    <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center justify-between hover:shadow-md transition-shadow">
      <div>
        <p className="text-slate-500 text-sm font-medium mb-1">{title}</p>
        <p className="text-3xl font-bold text-slate-800">{count}</p>
      </div>
      <div className={`p-4 rounded-xl ${bgClass}`}>
        <Icon className={colorClass} size={28} />
      </div>
    </div>
  );

  return (
    <div className="p-6 space-y-6 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">سلام، {user.name} 👋</h1>
          <p className="text-slate-500 mt-1">امروز {new Date().toLocaleDateString('fa-IR')}، وضعیت کارهای شما به شرح زیر است.</p>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="وظایف تاخیر خورده" count={overdueTasks.length} icon={AlertCircle} colorClass="text-red-600" bgClass="bg-red-50" />
        <StatCard title="وظایف امروز" count={inProgressTasks.length} icon={Clock} colorClass="text-blue-600" bgClass="bg-blue-50" />
        <StatCard title="انجام شده" count={doneTasks.length} icon={CheckCircle} colorClass="text-green-600" bgClass="bg-green-50" />
        <StatCard title="کل وظایف من" count={allTasks.length} icon={Calendar} colorClass="text-purple-600" bgClass="bg-purple-50" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Task List */}
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-slate-800">لیست وظایف من</h2>
            <div className="flex gap-2">
              <button className="text-xs bg-slate-100 text-slate-600 px-3 py-1 rounded-full hover:bg-slate-200">امروز</button>
              <button className="text-xs bg-transparent text-slate-500 px-3 py-1 rounded-full hover:bg-slate-100">هفته آتی</button>
            </div>
          </div>
          <div className="space-y-3">
            {allTasks.slice(0, 5).map(task => (
              <div key={task.id} className="flex items-center p-3 hover:bg-slate-50 rounded-xl transition-colors border border-transparent hover:border-slate-100 group">
                <div className={`w-2 h-2 rounded-full ml-4 ${
                  task.priority === 'High' ? 'bg-red-500' : 
                  task.priority === 'Medium' ? 'bg-yellow-500' : 'bg-green-500'
                }`}></div>
                <div className="flex-1">
                  <h3 className="text-sm font-semibold text-slate-800 group-hover:text-blue-600 transition-colors cursor-pointer">{task.title}</h3>
                  <p className="text-xs text-slate-500 mt-1">پروژه: {DataService.getProjects().find(p => p.id === task.projectId)?.name}</p>
                </div>
                <div className="flex items-center gap-4">
                  <span className={`text-xs px-2 py-1 rounded-md ${
                    task.status === 'Done' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-600'
                  }`}>
                    {task.status === 'Done' ? 'انجام شده' : 
                     task.status === 'In Progress' ? 'در حال انجام' : 'برای انجام'}
                  </span>
                  <span className="text-xs text-slate-400">{task.dueDate}</span>
                </div>
              </div>
            ))}
            {allTasks.length === 0 && <div className="text-center py-10 text-slate-400">وظیفه‌ای یافت نشد.</div>}
          </div>
        </div>

        {/* Charts */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 flex flex-col">
          <h2 className="text-lg font-bold text-slate-800 mb-6">وضعیت کلی</h2>
          <div className="flex-1 min-h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Meetings */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
           <h2 className="text-lg font-bold text-slate-800 mb-6">جلسات پیش رو</h2>
           <div className="space-y-4">
             {meetings.map(m => (
               <div key={m.id} className="flex gap-4 p-4 border border-slate-100 rounded-xl bg-slate-50/50">
                 <div className="bg-white p-2 rounded-lg text-center min-w-[60px] shadow-sm">
                   <span className="block text-xs text-slate-500">{m.date.split('/')[1]}</span>
                   <span className="block text-lg font-bold text-blue-600">{m.date.split('/')[2]}</span>
                 </div>
                 <div>
                   <h4 className="font-bold text-slate-800">{m.title}</h4>
                   <div className="flex items-center gap-2 mt-2 text-xs text-slate-500">
                     <Clock size={14} />
                     <span>{m.startTime} - {m.endTime}</span>
                   </div>
                 </div>
               </div>
             ))}
             {meetings.length === 0 && <p className="text-slate-500 text-sm">جلسه‌ای یافت نشد.</p>}
           </div>
        </div>

        {/* Weekly Performance */}
        <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6">
          <h2 className="text-lg font-bold text-slate-800 mb-6">عملکرد هفتگی</h2>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData}>
                <XAxis dataKey="name" tick={{fontSize: 12}} />
                <YAxis tick={{fontSize: 12}} />
                <Tooltip />
                <Bar dataKey="completed" fill="#3b82f6" name="انجام شده" radius={[4, 4, 0, 0]} />
                <Bar dataKey="new" fill="#cbd5e1" name="جدید" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};