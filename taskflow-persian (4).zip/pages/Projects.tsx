import React, { useState, useRef, useEffect, useMemo } from 'react';
import { DataService } from '../services/dataService';
import { Plus, MoreHorizontal, MapPin, Tag, FolderKanban, Settings, X, Trash2, Calendar as CalendarIcon, Users, AlignLeft, CheckSquare, Flag, Edit, Check, ListChecks, Database, ChevronRight, Clock, Paperclip, Send, User as UserIcon, Maximize2, Minimize2, Search, Bell, FileText, ChevronDown, Circle, LayoutList, Link as LinkIcon, Hash, ChevronUp, Play, StopCircle, Hourglass, Target, Layers, Layout, Table as TableIcon, ChartBar, Filter, ZoomIn, ZoomOut, RefreshCw } from 'lucide-react';
import { Project, CustomField, Task, TaskStatusType, SubTask, ActivityLog } from '../types';
import { PersianDatePicker } from '../components/PersianDatePicker';
import { CURRENT_USER } from '../constants';
import { toGregorian, toJalaali } from 'jalaali-js';

export const Projects: React.FC = () => {
  const [projects, setProjects] = useState(DataService.getProjects());
  const [selectedProject, setSelectedProject] = useState<Project | null>(projects[0] || null);
  const [tasks, setTasks] = useState(DataService.getTasks());
  const [allUsers] = useState(DataService.getUsers());
  
  // --- View Mode State ---
  const [viewMode, setViewMode] = useState<'board' | 'list' | 'gantt'>('board');
  const [boardGroupMode, setBoardGroupMode] = useState<'list' | 'status'>('list');
  const [zoomLevel, setZoomLevel] = useState(40); // Pixels per day for Gantt

  // --- Modal States ---
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isProjectModalOpen, setIsProjectModalOpen] = useState(false);
  const [isListModalOpen, setIsListModalOpen] = useState(false);
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  
  // --- UI Toggles for Task Modal ---
  const [showAssigneePicker, setShowAssigneePicker] = useState(false);
  const [showStatusPicker, setShowStatusPicker] = useState(false);
  const [showFieldPicker, setShowFieldPicker] = useState(false);
  const [showDependencyPicker, setShowDependencyPicker] = useState(false);
  const [showTagInput, setShowTagInput] = useState(false);
  
  // --- Board States ---
  const [expandedTaskIds, setExpandedTaskIds] = useState<Set<string>>(new Set());

  // --- Gantt Drag State ---
  const [dragState, setDragState] = useState<{taskId: string, startX: number, currentX: number} | null>(null);

  // --- Form States ---
  const [newProjectData, setNewProjectData] = useState<Partial<Project>>({
    name: '', code: '', type: 'Software', scope: 'Internal', location: '', startDate: '', endDate: ''
  });
  
  // Custom Fields for New Project
  const [newProjectCustomFields, setNewProjectCustomFields] = useState<CustomField[]>([]);
  const [tempFieldName, setTempFieldName] = useState('');
  const [tempFieldType, setTempFieldType] = useState<CustomField['type']>('text');
  const [tempFieldOptions, setTempFieldOptions] = useState('');

  const [newListName, setNewListName] = useState('');

  // Task Form (Create & Edit)
  const [activeListId, setActiveListId] = useState<string>('');
  const [editingTaskId, setEditingTaskId] = useState<string | null>(null);
  const [draftTaskId, setDraftTaskId] = useState<string>(''); // For linking subtasks during creation

  const [newTaskData, setNewTaskData] = useState<Partial<Task>>({
    title: '', description: '', priority: 'Medium', dueDate: '', assignees: [], subtasks: [], customFields: [], activityLog: [], status: 'Todo', tags: [], dependencies: [], sprintPoints: 0, timeEstimate: '', timeTracked: ''
  });
  
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');
  const [newComment, setNewComment] = useState('');
  const [newTag, setNewTag] = useState('');
  const [isTracking, setIsTracking] = useState(false);
  
  // Draft State
  const [draftLoaded, setDraftLoaded] = useState(false);

  // Activity Sidebar States
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Custom Field Form (Task)
  const [newFieldName, setNewFieldName] = useState('');
  const [newFieldType, setNewFieldType] = useState<CustomField['type']>('text');

  // Custom Field Form (Project Settings)
  const [settingsFieldName, setSettingsFieldName] = useState('');
  const [settingsFieldType, setSettingsFieldType] = useState<CustomField['type']>('text');
  const [settingsFieldOptions, setSettingsFieldOptions] = useState('');

  // Editing Custom Field State
  const [editingFieldId, setEditingFieldId] = useState<string | null>(null);
  const [editingFieldName, setEditingFieldName] = useState('');
  const [editingFieldType, setEditingFieldType] = useState<CustomField['type']>('text');

  // --- Helpers ---
  const getTasksForList = (projectId: string, listId: string) => {
    return tasks.filter(t => t.projectId === projectId && t.listId === listId && !t.parentId);
  };

  const getTasksForStatus = (projectId: string, status: string) => {
    return tasks.filter(t => t.projectId === projectId && t.status === status && !t.parentId);
  };

  const getSubtasksForTask = (taskId: string) => {
      return tasks.filter(t => t.parentId === taskId);
  };

  const toggleTaskExpansion = (taskId: string) => {
      const newSet = new Set(expandedTaskIds);
      if (newSet.has(taskId)) {
          newSet.delete(taskId);
      } else {
          newSet.add(taskId);
      }
      setExpandedTaskIds(newSet);
  };

  const updateProjectState = (updatedProject: Project) => {
    DataService.updateProject(updatedProject);
    setSelectedProject(updatedProject);
    setProjects(projects.map(p => p.id === updatedProject.id ? updatedProject : p));
  };

  const generateActivityLog = (action: ActivityLog['action'], details: string): ActivityLog => {
      return {
          id: Date.now().toString() + Math.random(),
          userId: CURRENT_USER.id,
          action,
          details,
          timestamp: new Date().toLocaleString('fa-IR')
      };
  };

  // --- Status Management ---
  const defaultStatuses = [
    { name: 'Todo', color: '#94a3b8', label: 'برای انجام' },
    { name: 'In Progress', color: '#3b82f6', label: 'در حال انجام' },
    { name: 'Review', color: '#eab308', label: 'بازبینی' },
    { name: 'Done', color: '#22c55e', label: 'انجام شده' },
  ];
  const [projectStatuses, setProjectStatuses] = useState(defaultStatuses);
  const [newStatusName, setNewStatusName] = useState('');

  const handleAddStatus = () => {
    if(!newStatusName.trim()) return;
    setProjectStatuses([...projectStatuses, { name: newStatusName, color: '#64748b', label: newStatusName }]);
    setNewStatusName('');
  };

  // --- Handlers ---
  const handleOpenNewProject = () => {
    setNewProjectData({ name: '', code: '', type: 'Software', scope: 'Internal', location: '', startDate: '', endDate: '' });
    setNewProjectCustomFields([]);
    setIsProjectModalOpen(true);
  };
  
  const handleAddTempField = () => {
    if (!tempFieldName.trim()) return;
    const field: CustomField = {
      id: Date.now().toString(),
      name: tempFieldName,
      type: tempFieldType,
      value: '',
      options: tempFieldType === 'select' ? tempFieldOptions.split(',').map(s => s.trim()).filter(Boolean) : undefined
    };
    setNewProjectCustomFields([...newProjectCustomFields, field]);
    setTempFieldName(''); setTempFieldType('text'); setTempFieldOptions('');
  };
  const handleRemoveTempField = (id: string) => setNewProjectCustomFields(newProjectCustomFields.filter(f => f.id !== id));

  const handleCreateProject = () => {
    if (!newProjectData.name) return;
    const newProject: Project = {
      id: Date.now().toString(),
      name: newProjectData.name || 'پروژه جدید',
      code: newProjectData.code || `PRJ-${Math.floor(Math.random() * 1000)}`,
      type: newProjectData.type || 'General',
      scope: newProjectData.scope || 'Internal',
      location: newProjectData.location || 'Remote',
      startDate: newProjectData.startDate || '',
      endDate: newProjectData.endDate || '',
      lists: [{ id: `l-${Date.now()}-1`, name: 'To Do' }, { id: `l-${Date.now()}-2`, name: 'Doing' }, { id: `l-${Date.now()}-3`, name: 'Done' }],
      customFields: newProjectCustomFields
    };
    const added = DataService.addProject(newProject);
    setProjects([...projects, added]);
    setSelectedProject(added);
    setIsProjectModalOpen(false);
  };

  const handleAddCustomFieldInSettings = () => {
    if (!selectedProject || !settingsFieldName.trim()) return;
    const newField: CustomField = {
      id: Date.now().toString(),
      name: settingsFieldName,
      type: settingsFieldType,
      value: '',
      options: settingsFieldType === 'select' ? settingsFieldOptions.split(',').map(s => s.trim()).filter(Boolean) : undefined
    };
    const updatedProject = { ...selectedProject, customFields: [...selectedProject.customFields, newField] };
    updateProjectState(updatedProject);
    setSettingsFieldName(''); setSettingsFieldType('text'); setSettingsFieldOptions('');
  };
  const handleRemoveCustomField = (fieldId: string) => {
    if (!selectedProject) return;
    if (window.confirm('آیا از حذف این فیلد اطمینان دارید؟')) {
        const updatedProject = { ...selectedProject, customFields: selectedProject.customFields.filter(f => f.id !== fieldId) };
        updateProjectState(updatedProject);
    }
  };
  const handleUpdateFieldValue = (fieldId: string, value: any) => {
    if (!selectedProject) return;
    const updatedProject = { ...selectedProject, customFields: selectedProject.customFields.map(f => f.id === fieldId ? { ...f, value } : f) };
    updateProjectState(updatedProject);
  };
  
  const handleOpenNewList = () => { setNewListName(''); setIsListModalOpen(true); };
  const handleCreateList = () => { 
      if (!selectedProject || !newListName.trim()) return;
      const newList = { id: `list-${Date.now()}`, name: newListName };
      const updatedProject = { ...selectedProject, lists: [...selectedProject.lists, newList] };
      updateProjectState(updatedProject);
      setIsListModalOpen(false);
  };

  // Auto-save draft effect
  useEffect(() => {
    if (isTaskModalOpen) {
      const key = editingTaskId ? `draft_task_${editingTaskId}` : 'draft_task_new';
      localStorage.setItem(key, JSON.stringify(newTaskData));
    }
  }, [newTaskData, isTaskModalOpen, editingTaskId]);

  const handleOpenNewTask = (listId: string) => {
    setEditingTaskId(null);
    setDraftTaskId(Date.now().toString()); // Generate ID for linking
    
    // Check for draft
    const savedDraft = localStorage.getItem('draft_task_new');
    if (savedDraft) {
        const parsed = JSON.parse(savedDraft);
        setNewTaskData(parsed);
        setActiveListId(parsed.listId || listId);
        setDraftLoaded(true);
    } else {
        setActiveListId(listId);
        setNewTaskData({ 
            title: '', description: '', priority: 'Medium', dueDate: '', assignees: [], tags: [], subtasks: [], customFields: [], activityLog: [], status: 'Todo', dependencies: [], sprintPoints: 0,
            listId: listId
        });
        setDraftLoaded(false);
    }
    
    setNewSubtaskTitle('');
    setIsTaskModalOpen(true);
    setIsTracking(false);
  };

  const handleEditTask = (task: Task) => {
    setEditingTaskId(task.id);
    setDraftTaskId('');
    
    // Check for draft
    const savedDraft = localStorage.getItem(`draft_task_${task.id}`);
    if (savedDraft) {
        setNewTaskData(JSON.parse(savedDraft));
        setActiveListId(task.listId);
        setDraftLoaded(true);
    } else {
        setActiveListId(task.listId);
        setNewTaskData({ ...task, customFields: task.customFields || [], activityLog: task.activityLog || [] });
        setDraftLoaded(false);
    }

    setNewSubtaskTitle('');
    setIsTaskModalOpen(true);
    setIsTracking(false);
  };

  const handleDiscardDraft = () => {
    const key = editingTaskId ? `draft_task_${editingTaskId}` : 'draft_task_new';
    localStorage.removeItem(key);
    
    if (editingTaskId) {
        const originalTask = tasks.find(t => t.id === editingTaskId);
        if (originalTask) {
            setNewTaskData({ ...originalTask, customFields: originalTask.customFields || [], activityLog: originalTask.activityLog || [] });
        }
    } else {
        setNewTaskData({ 
            title: '', description: '', priority: 'Medium', dueDate: '', assignees: [], tags: [], subtasks: [], customFields: [], activityLog: [], status: 'Todo', dependencies: [], sprintPoints: 0,
            listId: activeListId
        });
    }
    setDraftLoaded(false);
  };

  const handleToggleAssignee = (userId: string) => {
    const current = newTaskData.assignees || [];
    let newAssignees = [];
    if (current.includes(userId)) newAssignees = current.filter(id => id !== userId);
    else newAssignees = [...current, userId];
    setNewTaskData({ ...newTaskData, assignees: newAssignees });
    setShowAssigneePicker(false);
  };

  const handleAddSubtask = () => {
    if (!newSubtaskTitle.trim() || !selectedProject) return;
    const newSubTaskId = Date.now().toString() + Math.random().toString();
    const parentId = editingTaskId || draftTaskId;
    
    const newSubTask: Task = {
        id: newSubTaskId, title: newSubtaskTitle, status: 'Todo', priority: 'Medium', projectId: selectedProject.id, listId: activeListId, assignees: [], tags: [], subtasks: [], customFields: [], createdAt: new Date().toLocaleDateString('fa-IR'), 
        parentId: parentId,
    };
    
    // We add empty dates to the lightweight subtask representation
    const visualSubTask: SubTask = { 
        id: newSubTaskId, 
        title: newSubtaskTitle, 
        isCompleted: false, 
        linkedTaskId: newSubTaskId,
        startDate: '',
        dueDate: ''
    };
    
    const updatedSubtasks = [...(newTaskData.subtasks || []), visualSubTask];
    setNewTaskData({ ...newTaskData, subtasks: updatedSubtasks });
    
    DataService.addTask(newSubTask); 
    setTasks(DataService.getTasks()); 
    setNewSubtaskTitle('');
  };

  const updateSubtaskDate = (subtaskId: string, field: 'startDate' | 'dueDate', date: string) => {
    const updatedSubtasks = newTaskData.subtasks?.map(st => 
        st.id === subtaskId ? { ...st, [field]: date } : st
    );
    setNewTaskData({ ...newTaskData, subtasks: updatedSubtasks });
    
    const foundSubtask = updatedSubtasks?.find(s => s.id === subtaskId);
    const realTaskId = foundSubtask?.linkedTaskId || subtaskId;
    
    const realTask = tasks.find(t => t.id === realTaskId);
    if (realTask) {
         const updatedRealTask = { ...realTask, [field]: date };
         DataService.updateTask(updatedRealTask);
         setTasks(prev => prev.map(t => t.id === realTask.id ? updatedRealTask : t));
    }
  };

  const handleOpenSubtask = (subtask: SubTask) => {
      const realTask = tasks.find(t => t.id === subtask.linkedTaskId || t.id === subtask.id);
      if (realTask) handleEditTask(realTask);
      else alert("این زیرمجموعه هنوز به عنوان یک تسک مستقل ذخیره نشده است.");
  };

  const handleAddCustomFieldToTask = (type: CustomField['type'], name: string) => {
      const newField: CustomField = { id: Date.now().toString(), name: name, type: type, value: '' };
      setNewTaskData({ ...newTaskData, customFields: [...(newTaskData.customFields || []), newField] });
      setShowFieldPicker(false);
  };

  const handleAddDependency = (targetTaskId: string) => {
      if (targetTaskId === editingTaskId || newTaskData.dependencies?.includes(targetTaskId)) return;
      setNewTaskData({...newTaskData, dependencies: [...(newTaskData.dependencies || []), targetTaskId]});
      setShowDependencyPicker(false);
  };

  const handleAddTag = () => {
      if(!newTag.trim()) return;
      setNewTaskData({...newTaskData, tags: [...(newTaskData.tags || []), newTag.trim()]});
      setNewTag('');
      setShowTagInput(false);
  };

  const handleSaveTask = () => {
    if (!selectedProject || !newTaskData.title) return;
    let logs = newTaskData.activityLog || [];
    
    if (editingTaskId) {
      const originalTask = tasks.find(t => t.id === editingTaskId);
      if (!originalTask) return;
      const updatedTask: Task = { ...originalTask, ...newTaskData as Task, activityLog: logs };
      DataService.updateTask(updatedTask);
      setTasks(prev => prev.map(t => t.id === editingTaskId ? updatedTask : t));
    } else {
      const newTask: Task = {
        id: draftTaskId, // Use the draft ID we generated
        title: newTaskData.title || 'وظیفه جدید', description: newTaskData.description || '', status: newTaskData.status || 'Todo', priority: newTaskData.priority as any, projectId: selectedProject.id, listId: activeListId, assignees: newTaskData.assignees || [], tags: newTaskData.tags || [], subtasks: newTaskData.subtasks || [], customFields: newTaskData.customFields || [], createdAt: new Date().toLocaleDateString('fa-IR'), dueDate: newTaskData.dueDate || '', activityLog: logs, parentId: newTaskData.parentId, dependencies: newTaskData.dependencies, sprintPoints: newTaskData.sprintPoints, timeEstimate: newTaskData.timeEstimate, timeTracked: newTaskData.timeTracked
      };
      DataService.addTask(newTask);
      setTasks([...DataService.getTasks()]);
    }
    
    // Clear draft on save
    localStorage.removeItem(editingTaskId ? `draft_task_${editingTaskId}` : 'draft_task_new');
    setDraftLoaded(false);
    setIsTaskModalOpen(false);
  };

  const handleSendComment = () => {
      if(!newComment.trim()) return;
      const log = generateActivityLog('comment', newComment);
      setNewTaskData({ ...newTaskData, activityLog: [...(newTaskData.activityLog || []), log] });
      setNewComment('');
  };

  const handleDragStart = (e: React.DragEvent, taskId: string) => { e.dataTransfer.setData('taskId', taskId); };
  const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); };
  
  const handleListDrop = (e: React.DragEvent, targetListId: string) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('taskId');
    const taskToMove = tasks.find(t => t.id === taskId);
    if (!taskToMove || taskToMove.listId === targetListId) return;
    const updatedTask = { ...taskToMove, listId: targetListId };
    setTasks(tasks.map(t => t.id === taskId ? updatedTask : t));
    DataService.updateTask(updatedTask);
  };

  const handleStatusDrop = (e: React.DragEvent, targetStatus: string) => {
    e.preventDefault();
    const taskId = e.dataTransfer.getData('taskId');
    const taskToMove = tasks.find(t => t.id === taskId);
    if (!taskToMove || taskToMove.status === targetStatus) return;
    const updatedTask = { ...taskToMove, status: targetStatus };
    setTasks(tasks.map(t => t.id === taskId ? updatedTask : t));
    DataService.updateTask(updatedTask);
  };

  const getStatusColor = (status: string) => projectStatuses.find(s => s.name === status)?.color || '#94a3b8';
  const getStatusLabel = (status: string) => projectStatuses.find(s => s.name === status)?.label || status;
  const handleStartDateChange = (date: string) => selectedProject && updateProjectState({ ...selectedProject, startDate: date });
  const handleEndDateChange = (date: string) => selectedProject && updateProjectState({ ...selectedProject, endDate: date });

  // UI Components helpers
  const PropRow = ({ icon: Icon, label, children }: any) => (
      <div className="flex items-center min-h-[40px] group">
          <div className="w-36 flex items-center gap-2 text-slate-400 text-sm">
              <Icon size={16} className="text-slate-400 group-hover:text-slate-500 transition-colors" />
              <span>{label}</span>
          </div>
          <div className="flex-1">
              {children}
          </div>
      </div>
  );

  const TaskCard = ({ task, subtasks }: { task: Task, subtasks: Task[] }) => (
      <div draggable onDragStart={(e) => handleDragStart(e, task.id)} onClick={() => handleEditTask(task)} className="bg-white p-4 rounded-lg shadow-sm border border-slate-200 cursor-pointer hover:shadow-md">
         <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full" style={{backgroundColor: getStatusColor(task.status)}}></span>
            <span className="text-xs text-slate-400 font-mono">#{task.id.slice(-4)}</span>
         </div>
         <h4 className="text-sm font-semibold text-slate-800 mb-2">{task.title}</h4>
         <div className="flex flex-col gap-2 mb-2">
             <div className="flex justify-between items-center">
                <div className="flex -space-x-2 space-x-reverse">
                    {task.assignees.map(uid => <img key={uid} src={allUsers.find(u=>u.id===uid)?.avatar} className="w-6 h-6 rounded-full border border-white" />)}
                </div>
             </div>
             <div className="flex items-center gap-2 text-xs text-slate-500">
                {task.startDate && (
                    <span className="flex items-center gap-1 bg-slate-50 px-1.5 py-0.5 rounded border border-slate-100">
                       <span className="text-[10px] text-slate-400">شروع:</span> {task.startDate}
                    </span>
                )}
                {task.dueDate && (
                    <span className="flex items-center gap-1 bg-slate-50 px-1.5 py-0.5 rounded border border-slate-100">
                       <span className="text-[10px] text-slate-400">تحویل:</span> {task.dueDate}
                    </span>
                )}
            </div>
         </div>
         
         {/* Subtask Dropdown (Accordion) */}
         {subtasks.length > 0 && (
            <div className="mt-3 pt-3 border-t border-slate-100">
                <button 
                    onClick={(e) => { e.stopPropagation(); toggleTaskExpansion(task.id); }}
                    className="flex items-center gap-1 text-xs text-slate-500 hover:text-blue-600 transition-colors w-full"
                >
                    {expandedTaskIds.has(task.id) ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                    <span className="font-medium">{subtasks.length} زیرمجموعه</span>
                </button>
                
                {expandedTaskIds.has(task.id) && (
                    <div className="mt-2 space-y-1 pl-1 pr-1 border-r border-slate-200 mr-1 animate-in slide-in-from-top-1 fade-in duration-200">
                        {subtasks.map(st => (
                            <div 
                                key={st.id} 
                                onClick={(e) => { e.stopPropagation(); handleEditTask(st); }}
                                className="flex items-center justify-between p-2 bg-slate-50 rounded text-xs hover:bg-blue-50 transition-colors"
                            >
                                <span className="truncate flex-1 text-slate-700">{st.title}</span>
                                <span className="w-1.5 h-1.5 rounded-full" style={{backgroundColor: getStatusColor(st.status)}}></span>
                            </div>
                        ))}
                    </div>
                )}
            </div>
         )}
      </div>
  );

  // --- Gantt View Helpers ---
  const parsePersianDate = (dateStr?: string) => {
      if (!dateStr) return null;
      const parts = dateStr.split('/');
      if (parts.length !== 3) return null;
      const { gy, gm, gd } = toGregorian(parseInt(parts[0]), parseInt(parts[1]), parseInt(parts[2]));
      return new Date(gy, gm - 1, gd);
  };

  const addDaysToJalaali = (dateStr: string, days: number): string => {
      const gDate = parsePersianDate(dateStr);
      if (!gDate) return dateStr;
      
      const newGDate = new Date(gDate);
      newGDate.setDate(newGDate.getDate() + days);
      
      const jDate = toJalaali(newGDate.getFullYear(), newGDate.getMonth() + 1, newGDate.getDate());
      return `${jDate.jy}/${String(jDate.jm).padStart(2, '0')}/${String(jDate.jd).padStart(2, '0')}`;
  };

  const ganttData = useMemo(() => {
    if (!selectedProject) return null;
    const projectTasks = tasks.filter(t => t.projectId === selectedProject.id && !t.parentId); // Only top level tasks in chart
    
    // Flatten tasks for Gantt
    const items = projectTasks.map(t => {
        const start = parsePersianDate(t.startDate) || new Date(); // Fallback to now if missing
        let end = parsePersianDate(t.dueDate);
        if (!end || end < start) end = new Date(start.getTime() + 86400000); // Default 1 day duration

        return {
            ...t,
            start,
            end,
            duration: Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24))
        };
    });

    if (items.length === 0) return null;

    const minDate = new Date(Math.min(...items.map(i => i.start.getTime())));
    const maxDate = new Date(Math.max(...items.map(i => i.end.getTime())));
    
    // Add buffer
    minDate.setDate(minDate.getDate() - 3);
    maxDate.setDate(maxDate.getDate() + 7);

    const totalDays = Math.ceil((maxDate.getTime() - minDate.getTime()) / (1000 * 60 * 60 * 24));
    
    return { items, minDate, maxDate, totalDays };
  }, [tasks, selectedProject]);

  // --- Drag & Drop for Gantt Rescheduling ---
  const handleGanttMouseDown = (e: React.MouseEvent, taskId: string) => {
      e.stopPropagation();
      setDragState({ taskId, startX: e.clientX, currentX: e.clientX });
  };

  useEffect(() => {
      const handleMouseMove = (e: MouseEvent) => {
          if (dragState) {
              setDragState(prev => prev ? { ...prev, currentX: e.clientX } : null);
          }
      };

      const handleMouseUp = (e: MouseEvent) => {
          if (dragState) {
              const deltaX = dragState.currentX - dragState.startX;
              // In RTL logic for this chart:
              // Start Date is at right: offset * zoom.
              // Dragging LEFT (negative delta) means increasing pixel offset from right -> Date increases.
              // Dragging RIGHT (positive delta) means decreasing pixel offset from right -> Date decreases.
              // So, shift = -deltaX / zoomLevel
              const daysShifted = Math.round(-deltaX / zoomLevel);

              if (daysShifted !== 0) {
                  const task = tasks.find(t => t.id === dragState.taskId);
                  if (task && task.startDate && task.dueDate) {
                      const newStartDate = addDaysToJalaali(task.startDate, daysShifted);
                      const newDueDate = addDaysToJalaali(task.dueDate, daysShifted);
                      
                      const updatedTask = { ...task, startDate: newStartDate, dueDate: newDueDate };
                      DataService.updateTask(updatedTask);
                      setTasks(prev => prev.map(t => t.id === task.id ? updatedTask : t));
                  }
              }
              setDragState(null);
          }
      };

      if (dragState) {
          window.addEventListener('mousemove', handleMouseMove);
          window.addEventListener('mouseup', handleMouseUp);
      }

      return () => {
          window.removeEventListener('mousemove', handleMouseMove);
          window.removeEventListener('mouseup', handleMouseUp);
      };
  }, [dragState, zoomLevel, tasks]);

  // Render Logic
  return (
    <div className="flex h-[calc(100vh-64px)] overflow-hidden relative font-sans">
      {/* ... Sidebar ... */}
      <div className="w-64 bg-white border-l border-slate-200 flex flex-col overflow-y-auto">
         <div className="p-4 border-b border-slate-100 flex justify-between items-center">
          <h2 className="font-bold text-slate-700">پروژه‌ها</h2>
          <button onClick={handleOpenNewProject} className="text-blue-600 hover:bg-blue-50 p-1 rounded transition-colors"><Plus size={18} /></button>
        </div>
        <div className="p-2 space-y-1">
          {projects.map(p => (
            <button key={p.id} onClick={() => setSelectedProject(p)} className={`w-full text-right px-4 py-3 rounded-lg text-sm transition-colors flex flex-col items-start gap-1 ${selectedProject?.id === p.id ? 'bg-blue-50' : 'hover:bg-slate-50'}`}>
              <div className="w-full flex items-center justify-between">
                 <span className={`${selectedProject?.id === p.id ? 'text-blue-700 font-medium' : 'text-slate-700'}`}>{p.name}</span>
                 {selectedProject?.id === p.id && <div className="w-1.5 h-1.5 rounded-full bg-blue-600"></div>}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Main Board */}
      <div className="flex-1 flex flex-col bg-slate-50/50 overflow-hidden">
        {selectedProject ? (
          <>
            <div className="bg-white border-b border-slate-200 px-6 py-4">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h1 className="text-2xl font-bold text-slate-800">{selectedProject.name}</h1>
                    <span className="bg-slate-100 text-slate-600 text-xs px-2 py-1 rounded border border-slate-200">{selectedProject.code}</span>
                  </div>
                  {/* ... Metadata & Fields ... */}
                  {selectedProject.customFields.length > 0 && (
                      <div className="flex flex-wrap gap-3 mt-2">
                        {selectedProject.customFields.map(field => (
                            <div key={field.id} className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200 text-xs">
                                <span className="font-medium text-slate-600">{field.name}:</span>
                                <span>{field.value?.toString()}</span>
                            </div>
                        ))}
                      </div>
                  )}
                </div>
                <div className="flex gap-2">
                    {/* View Switcher */}
                    <div className="flex bg-slate-100 p-1 rounded-lg items-center">
                        <button onClick={() => setViewMode('list')} className={`p-2 rounded-md transition-colors ${viewMode === 'list' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`} title="نمای لیست">
                            <TableIcon size={18} />
                        </button>
                        <button onClick={() => setViewMode('board')} className={`p-2 rounded-md transition-colors ${viewMode === 'board' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`} title="نمای برد">
                            <Layout size={18} />
                        </button>
                        <button onClick={() => setViewMode('gantt')} className={`p-2 rounded-md transition-colors ${viewMode === 'gantt' ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-700'}`} title="نمای گانت">
                            <ChartBar size={18} />
                        </button>
                    </div>

                    {/* Gantt Zoom Controls */}
                    {viewMode === 'gantt' && (
                        <div className="flex bg-slate-100 p-1 rounded-lg items-center animate-in fade-in slide-in-from-right-2">
                             <button onClick={() => setZoomLevel(Math.max(20, zoomLevel - 10))} className="p-2 text-slate-500 hover:text-slate-700 rounded-md" title="کوچک‌نمایی">
                                 <ZoomOut size={16} />
                             </button>
                             <span className="text-xs text-slate-400 w-8 text-center">{zoomLevel}px</span>
                             <button onClick={() => setZoomLevel(Math.min(100, zoomLevel + 10))} className="p-2 text-slate-500 hover:text-slate-700 rounded-md" title="بزرگ‌نمایی">
                                 <ZoomIn size={16} />
                             </button>
                        </div>
                    )}

                    <div className="h-9 w-px bg-slate-200 mx-1"></div>

                    <button onClick={() => setIsSettingsOpen(true)} className="px-3 py-2 bg-slate-100 text-slate-600 text-sm rounded-lg hover:bg-slate-200 flex items-center gap-2 transition-colors"><Settings size={18} /></button>
                    <button onClick={handleOpenNewList} className="px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 flex items-center gap-2"><Plus size={16} /> لیست جدید</button>
                </div>
              </div>
              
              {/* Secondary Toolbar for Board View */}
              {viewMode === 'board' && (
                  <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-100 animate-in fade-in slide-in-from-top-1">
                      <span className="text-xs text-slate-500 font-medium ml-2">دسته‌بندی بر اساس:</span>
                      <div className="flex bg-slate-100 p-0.5 rounded-lg">
                          <button 
                            onClick={() => setBoardGroupMode('list')} 
                            className={`px-3 py-1 text-xs rounded-md transition-all ${boardGroupMode === 'list' ? 'bg-white text-blue-600 shadow-sm font-medium' : 'text-slate-500 hover:text-slate-700'}`}
                          >
                             لیست‌ها
                          </button>
                          <button 
                            onClick={() => setBoardGroupMode('status')} 
                            className={`px-3 py-1 text-xs rounded-md transition-all ${boardGroupMode === 'status' ? 'bg-white text-blue-600 shadow-sm font-medium' : 'text-slate-500 hover:text-slate-700'}`}
                          >
                             وضعیت
                          </button>
                      </div>
                  </div>
              )}
            </div>

            <div className="flex-1 overflow-hidden p-6">
              {/* BOARD VIEW */}
              {viewMode === 'board' && (
                  <div className="flex h-full overflow-x-auto space-x-6 space-x-reverse min-w-max pb-2">
                    {boardGroupMode === 'list' ? (
                        // Group by List
                        selectedProject.lists.map(list => (
                          <div key={list.id} className="w-80 flex flex-col h-full rounded-xl bg-slate-100/50 border border-slate-200/60" onDragOver={handleDragOver} onDrop={(e) => handleListDrop(e, list.id)}>
                            <div className="p-3 flex justify-between items-center bg-slate-100 rounded-t-xl">
                              <h3 className="font-bold text-slate-700 text-sm">{list.name}</h3>
                              <button onClick={() => handleOpenNewTask(list.id)}><Plus size={16} /></button>
                            </div>
                            <div className="p-3 space-y-3 overflow-y-auto flex-1 custom-scrollbar">
                              {getTasksForList(selectedProject.id, list.id).map(task => (
                                  <TaskCard key={task.id} task={task} subtasks={getSubtasksForTask(task.id)} />
                              ))}
                            </div>
                          </div>
                        ))
                    ) : (
                        // Group by Status
                        projectStatuses.map(status => (
                            <div key={status.name} className="w-80 flex flex-col h-full rounded-xl bg-slate-100/50 border border-slate-200/60" onDragOver={handleDragOver} onDrop={(e) => handleStatusDrop(e, status.name)}>
                                <div className="p-3 flex justify-between items-center bg-slate-100 rounded-t-xl border-b-2" style={{borderColor: status.color}}>
                                  <div className="flex items-center gap-2">
                                     <span className="w-3 h-3 rounded-full" style={{backgroundColor: status.color}}></span>
                                     <h3 className="font-bold text-slate-700 text-sm">{status.label}</h3>
                                  </div>
                                </div>
                                <div className="p-3 space-y-3 overflow-y-auto flex-1 custom-scrollbar">
                                  {getTasksForStatus(selectedProject.id, status.name).map(task => (
                                      <TaskCard key={task.id} task={task} subtasks={getSubtasksForTask(task.id)} />
                                  ))}
                                </div>
                            </div>
                        ))
                    )}
                  </div>
              )}

              {/* LIST VIEW */}
              {viewMode === 'list' && (
                  <div className="h-full overflow-y-auto custom-scrollbar bg-white rounded-xl border border-slate-200 shadow-sm">
                      {selectedProject.lists.map(list => {
                         const listTasks = getTasksForList(selectedProject.id, list.id);
                         return (
                           <div key={list.id} className="border-b border-slate-100 last:border-0">
                               <div className="bg-slate-50 px-4 py-3 font-bold text-slate-700 flex justify-between items-center sticky top-0 z-10 border-b border-slate-200">
                                   <div className="flex items-center gap-2">
                                     <span className="bg-white border border-slate-200 px-2 py-0.5 rounded text-xs text-slate-500">{listTasks.length}</span>
                                     {list.name}
                                   </div>
                                   <button onClick={() => handleOpenNewTask(list.id)} className="text-blue-600 hover:bg-blue-100 p-1 rounded"><Plus size={16}/></button>
                               </div>
                               <table className="w-full text-sm text-right">
                                   <thead className="text-xs text-slate-400 font-medium border-b border-slate-100 bg-white">
                                       <tr>
                                           <th className="px-4 py-2 font-normal w-8">#</th>
                                           <th className="px-4 py-2 font-normal">عنوان وظیفه</th>
                                           <th className="px-4 py-2 font-normal w-32">وضعیت</th>
                                           <th className="px-4 py-2 font-normal w-32">مسئولین</th>
                                           <th className="px-4 py-2 font-normal w-32">تاریخ شروع</th>
                                           <th className="px-4 py-2 font-normal w-32">تاریخ تحویل</th>
                                           <th className="px-4 py-2 font-normal w-24">اولویت</th>
                                       </tr>
                                   </thead>
                                   <tbody className="divide-y divide-slate-50">
                                       {listTasks.map(task => (
                                           <tr key={task.id} onClick={() => handleEditTask(task)} className="hover:bg-slate-50 cursor-pointer group transition-colors">
                                               <td className="px-4 py-3 text-slate-400 text-xs font-mono">{task.id.slice(-4)}</td>
                                               <td className="px-4 py-3 font-medium text-slate-700 group-hover:text-blue-600">{task.title}</td>
                                               <td className="px-4 py-3">
                                                   <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-xs font-medium" style={{backgroundColor: `${getStatusColor(task.status)}20`, color: getStatusColor(task.status)}}>
                                                       <span className="w-1.5 h-1.5 rounded-full" style={{backgroundColor: getStatusColor(task.status)}}></span>
                                                       {getStatusLabel(task.status)}
                                                   </span>
                                               </td>
                                               <td className="px-4 py-3">
                                                   <div className="flex -space-x-2 space-x-reverse">
                                                       {task.assignees.map(uid => <img key={uid} src={allUsers.find(u=>u.id===uid)?.avatar} className="w-6 h-6 rounded-full border border-white" title={allUsers.find(u=>u.id===uid)?.name} />)}
                                                       {task.assignees.length === 0 && <span className="text-slate-300 text-xs">-</span>}
                                                   </div>
                                               </td>
                                               <td className="px-4 py-3 text-slate-500 text-xs font-mono">{task.startDate || '-'}</td>
                                               <td className="px-4 py-3 text-slate-500 text-xs font-mono">{task.dueDate || '-'}</td>
                                               <td className="px-4 py-3">
                                                   <span className={`text-xs px-2 py-0.5 rounded ${task.priority === 'Urgent' ? 'bg-red-100 text-red-700' : task.priority === 'High' ? 'bg-orange-100 text-orange-700' : task.priority === 'Medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-slate-100 text-slate-600'}`}>
                                                       {task.priority}
                                                   </span>
                                               </td>
                                           </tr>
                                       ))}
                                       {listTasks.length === 0 && (
                                           <tr><td colSpan={7} className="text-center py-4 text-slate-400 text-xs">خالی</td></tr>
                                       )}
                                   </tbody>
                               </table>
                           </div>
                         );
                      })}
                  </div>
              )}

              {/* GANTT VIEW */}
              {viewMode === 'gantt' && (
                  <div className="h-full bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col select-none">
                      {ganttData ? (
                          <div className="flex-1 overflow-auto custom-scrollbar relative">
                              <div className="min-w-max">
                                  {/* Header Days */}
                                  <div className="flex border-b border-slate-200 sticky top-0 bg-slate-50 z-20">
                                      <div className="w-60 flex-shrink-0 p-3 border-l border-slate-200 font-bold text-slate-700 text-sm sticky right-0 bg-slate-50 z-30 shadow-sm">وظیفه</div>
                                      <div className="flex">
                                          {Array.from({length: ganttData.totalDays}).map((_, i) => {
                                              const date = new Date(ganttData.minDate);
                                              date.setDate(date.getDate() + i);
                                              const isToday = new Date().toDateString() === date.toDateString();
                                              return (
                                                  <div key={i} className={`flex-shrink-0 border-l border-slate-100 text-center py-2 text-xs ${isToday ? 'bg-blue-50 text-blue-600 font-bold' : 'text-slate-500'}`} style={{width: `${zoomLevel}px`}}>
                                                      {date.toLocaleDateString('fa-IR', {day: '2-digit'})}
                                                      <span className="block text-[10px] opacity-60">{date.toLocaleDateString('fa-IR', {month: 'short'})}</span>
                                                  </div>
                                              );
                                          })}
                                      </div>
                                  </div>
                                  
                                  {/* Rows */}
                                  <div className="relative">
                                      {/* Background Grid */}
                                      <div className="absolute inset-0 flex pl-60">
                                           {Array.from({length: ganttData.totalDays}).map((_, i) => (
                                               <div key={i} className="flex-shrink-0 border-l border-slate-50 h-full" style={{width: `${zoomLevel}px`}}></div>
                                           ))}
                                      </div>
                                      
                                      {/* Tasks */}
                                      {ganttData.items.map(item => {
                                          const offsetDays = Math.ceil((item.start.getTime() - ganttData.minDate.getTime()) / (1000 * 60 * 60 * 24));
                                          const widthDays = item.duration;
                                          const isDragging = dragState?.taskId === item.id;
                                          const dragOffset = isDragging ? (dragState.currentX - dragState.startX) : 0;
                                          
                                          return (
                                              <div key={item.id} className="flex border-b border-slate-100 hover:bg-slate-50 transition-colors relative h-10 items-center group">
                                                  <div className="w-60 flex-shrink-0 px-4 py-2 border-l border-slate-200 text-sm text-slate-700 truncate sticky right-0 bg-white group-hover:bg-slate-50 z-10 flex items-center justify-between">
                                                      <span className="truncate">{item.title}</span>
                                                      <button onClick={() => handleEditTask(item)} className="opacity-0 group-hover:opacity-100 text-blue-600"><Edit size={14}/></button>
                                                  </div>
                                                  <div className="flex-1 relative h-full">
                                                      <div 
                                                          className={`absolute top-2 h-6 rounded-md shadow-sm border border-white/20 text-xs text-white px-2 flex items-center truncate cursor-grab active:cursor-grabbing hover:brightness-110 transition-all ${isDragging ? 'z-20 shadow-lg ring-2 ring-blue-300 opacity-90' : ''}`}
                                                          style={{
                                                              right: `${offsetDays * zoomLevel}px`, // RTL Logic: Right offset
                                                              width: `${widthDays * zoomLevel}px`,
                                                              backgroundColor: getStatusColor(item.status),
                                                              transform: `translateX(${dragOffset}px)`,
                                                              transition: isDragging ? 'none' : 'transform 0.2s, right 0.2s',
                                                          }}
                                                          onMouseDown={(e) => handleGanttMouseDown(e, item.id)}
                                                      >
                                                          {item.title}
                                                      </div>
                                                  </div>
                                              </div>
                                          );
                                      })}
                                  </div>
                              </div>
                          </div>
                      ) : (
                          <div className="flex items-center justify-center h-full text-slate-400">داده‌ای برای نمایش گانت چارت وجود ندارد. لطفا تاریخ شروع و پایان وظایف را تنظیم کنید.</div>
                      )}
                  </div>
              )}
            </div>
          </>
        ) : ( <div className="flex items-center justify-center h-full">لطفا یک پروژه را انتخاب کنید</div> )}
      </div>

      {/* --- MODALs (Project, Settings, List, Task) --- */}
      {isProjectModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in">
             <div className="bg-white rounded-2xl p-6 w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
                 <div className="flex justify-between mb-4"><h3>پروژه جدید</h3><button onClick={()=>setIsProjectModalOpen(false)}><X/></button></div>
                 <div className="overflow-y-auto custom-scrollbar flex-1">
                 <input className="w-full border p-2 rounded mb-4" placeholder="نام پروژه" value={newProjectData.name} onChange={e=>setNewProjectData({...newProjectData, name: e.target.value})} />
                 <button onClick={handleCreateProject} className="bg-blue-600 text-white px-4 py-2 rounded">ایجاد</button>
                 </div>
             </div>
        </div>
      )}

       {isSettingsOpen && selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in">
            <div className="bg-white rounded-2xl p-6 w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
                 <div className="flex justify-between mb-4"><h3>تنظیمات</h3><button onClick={()=>setIsSettingsOpen(false)}><X/></button></div>
                 <div className="overflow-y-auto custom-scrollbar flex-1">
                 <div className="flex gap-2 mb-4">
                    <input className="border p-2 rounded flex-1" placeholder="فیلد جدید" value={settingsFieldName} onChange={e=>setSettingsFieldName(e.target.value)} />
                    <button onClick={handleAddCustomFieldInSettings} className="bg-blue-600 text-white px-3 py-2 rounded">افزودن</button>
                 </div>
                 <div className="max-h-60 overflow-y-auto">
                    {selectedProject.customFields.map(f => (
                        <div key={f.id} className="flex justify-between p-2 border-b"><span className="text-sm">{f.name}</span><button onClick={()=>handleRemoveCustomField(f.id)}><Trash2 size={14}/></button></div>
                    ))}
                 </div>
                 </div>
            </div>
        </div>
      )}
      
      {isListModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 animate-in fade-in">
              <div className="bg-white rounded-2xl p-6 w-full max-w-sm">
                  <h3 className="mb-4 font-bold">لیست جدید</h3>
                  <input className="w-full border p-2 rounded mb-4" value={newListName} onChange={e=>setNewListName(e.target.value)} placeholder="نام لیست" />
                  <button onClick={handleCreateList} className="bg-blue-600 text-white px-4 py-2 rounded w-full">افزودن</button>
              </div>
          </div>
      )}

      {isTaskModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
           <div className="bg-white rounded-xl shadow-2xl w-full max-w-[1200px] h-[90vh] overflow-hidden flex flex-col md:flex-row relative">
              <div className="flex-1 flex flex-col h-full overflow-hidden bg-white">
                  {/* Task Header */}
                  <div className="px-8 py-4 border-b border-slate-100 flex justify-between items-center bg-white sticky top-0 z-10">
                      <div className="flex items-center gap-2 text-sm text-slate-500">
                         <button className="flex items-center gap-1.5 hover:bg-slate-100 px-2 py-1 rounded transition-colors">
                              <span className="w-2 h-2 rounded-full bg-slate-400"></span>
                              Task <ChevronDown size={12} />
                          </button>
                          <span className="text-slate-300">/</span>
                          <span className="font-mono">{editingTaskId ? `#${editingTaskId.substring(0,4)}` : 'New'}</span>
                          
                          {/* Draft Indicator */}
                          {draftLoaded && (
                            <span className="bg-yellow-100 text-yellow-700 text-xs px-2 py-0.5 rounded-full flex items-center gap-1 border border-yellow-200 animate-pulse">
                                <Clock size={10} /> پیش‌نویس
                            </span>
                          )}
                      </div>
                      <div className="flex items-center gap-2">
                        {draftLoaded && (
                            <button onClick={handleDiscardDraft} className="text-red-400 hover:text-red-600 hover:bg-red-50 p-1.5 rounded-lg transition-colors text-xs flex items-center gap-1" title="حذف پیش‌نویس">
                                <Trash2 size={16} /> <span className="hidden md:inline">حذف پیش‌نویس</span>
                            </button>
                        )}
                        <div className="w-px h-4 bg-slate-200 mx-1"></div>
                        <button onClick={() => setIsTaskModalOpen(false)}><X size={20} className="text-slate-400 hover:text-slate-600" /></button>
                      </div>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
                      {/* Title */}
                      <input type="text" className="w-full text-4xl font-bold text-slate-800 placeholder-slate-300 border-none focus:ring-0 focus:outline-none bg-transparent mb-8"
                        placeholder="عنوان وظیفه..." value={newTaskData.title} onChange={e => setNewTaskData({...newTaskData, title: e.target.value})} autoFocus />
                      
                      {/* Properties Grid (ClickUp Style) */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4 mb-10">
                          {/* Column 1 */}
                          <div className="space-y-4">
                              <PropRow icon={Circle} label="وضعیت">
                                  <div className="relative">
                                      <button onClick={() => setShowStatusPicker(!showStatusPicker)} className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded text-sm font-medium transition-colors" style={{ color: getStatusColor(newTaskData.status as string) }}>
                                          <span className="uppercase">{getStatusLabel(newTaskData.status as string)}</span><ChevronDown size={14} />
                                      </button>
                                      {showStatusPicker && (
                                          <div className="absolute top-full right-0 mt-1 w-56 bg-white border border-slate-200 rounded-lg shadow-xl z-20 p-2 animate-in fade-in zoom-in-95">
                                              {projectStatuses.map(s => (
                                                  <button key={s.name} onClick={() => { setNewTaskData({...newTaskData, status: s.name}); setShowStatusPicker(false); }} className="w-full flex items-center gap-2 px-2 py-1.5 hover:bg-slate-50 rounded text-sm text-right">
                                                      <span className="w-2.5 h-2.5 rounded-sm" style={{backgroundColor: s.color}}></span>{s.label}
                                                  </button>
                                              ))}
                                          </div>
                                      )}
                                  </div>
                              </PropRow>

                              <PropRow icon={CalendarIcon} label="زمان‌بندی">
                                  <div className="flex items-center gap-2">
                                      <PersianDatePicker value={newTaskData.startDate || ''} onChange={d => setNewTaskData({...newTaskData, startDate: d})} label="" />
                                      <span className="text-slate-300">→</span>
                                      <PersianDatePicker value={newTaskData.dueDate || ''} onChange={d => setNewTaskData({...newTaskData, dueDate: d})} label="" />
                                  </div>
                              </PropRow>

                              <PropRow icon={Hourglass} label="تخمین زمان">
                                  <input className="bg-transparent text-sm hover:bg-slate-50 focus:bg-white border-none rounded px-2 py-1 w-full placeholder-slate-400" 
                                    placeholder="مثلا: 2h 30m" value={newTaskData.timeEstimate} onChange={e => setNewTaskData({...newTaskData, timeEstimate: e.target.value})} />
                              </PropRow>

                              <PropRow icon={Clock} label="ثبت زمان">
                                  <div className="flex items-center gap-2">
                                     <button onClick={() => setIsTracking(!isTracking)} className={`flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium transition-all ${isTracking ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-600 hover:bg-blue-50 hover:text-blue-600'}`}>
                                         {isTracking ? <StopCircle size={16} /> : <Play size={16} />}
                                         {isTracking ? 'توقف زمان' : 'شروع'}
                                     </button>
                                     <span className="text-sm text-slate-500">{newTaskData.timeTracked || '0h 0m'}</span>
                                  </div>
                              </PropRow>
                          </div>

                          {/* Column 2 */}
                          <div className="space-y-4">
                              <PropRow icon={Users} label="مسئولین">
                                   <div className="relative flex flex-wrap gap-1 items-center">
                                      {newTaskData.assignees?.map(uid => {
                                          const u = allUsers.find(user => user.id === uid);
                                          return u ? (
                                            <div key={uid} className="relative group/avatar cursor-pointer" onClick={() => handleToggleAssignee(uid)}>
                                                <img src={u.avatar} className="w-6 h-6 rounded-full border border-white hover:border-red-400" />
                                                <div className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover/avatar:opacity-100 whitespace-nowrap z-30 transition-opacity">
                                                    {u.name} (حذف)
                                                </div>
                                            </div>
                                          ) : null;
                                      })}
                                      <button onClick={() => setShowAssigneePicker(!showAssigneePicker)} className="text-slate-400 hover:text-blue-600 hover:bg-blue-50 p-1 rounded transition-colors">{newTaskData.assignees?.length === 0 ? <span className="text-sm text-slate-300">Empty</span> : <Plus size={18} />}</button>
                                      {showAssigneePicker && (
                                          <div className="absolute top-full left-0 mt-1 w-64 bg-white border border-slate-200 rounded-lg shadow-xl z-20 p-2 animate-in fade-in zoom-in-95">
                                              <div className="max-h-48 overflow-y-auto space-y-1">
                                                  {allUsers.map(u => {
                                                      const isSelected = newTaskData.assignees?.includes(u.id);
                                                      return (
                                                          <button key={u.id} onClick={() => handleToggleAssignee(u.id)} className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-sm text-right ${isSelected ? 'bg-blue-50 text-blue-700' : 'hover:bg-slate-50'}`}>
                                                              <img src={u.avatar} className="w-6 h-6 rounded-full" /><span className="flex-1">{u.name}</span>{isSelected && <Check size={14} />}
                                                          </button>
                                                      );
                                                  })}
                                              </div>
                                          </div>
                                      )}
                                  </div>
                              </PropRow>

                              <PropRow icon={Flag} label="اولویت">
                                  <select className="bg-transparent text-sm text-slate-700 focus:outline-none cursor-pointer hover:bg-slate-50 rounded px-2 py-1 -mr-2 w-full"
                                      value={newTaskData.priority} onChange={(e) => setNewTaskData({...newTaskData, priority: e.target.value as any})}>
                                      <option value="Low">پایین</option>
                                      <option value="Medium">متوسط</option>
                                      <option value="High">بالا</option>
                                      <option value="Urgent">فوری</option>
                                  </select>
                              </PropRow>

                              <PropRow icon={Target} label="امتیاز اسپرینت">
                                  <input type="number" className="bg-transparent text-sm hover:bg-slate-50 focus:bg-white border-none rounded px-2 py-1 w-20 placeholder-slate-400" 
                                    placeholder="-" value={newTaskData.sprintPoints || ''} onChange={e => setNewTaskData({...newTaskData, sprintPoints: parseInt(e.target.value) || 0})} />
                              </PropRow>

                              <PropRow icon={Tag} label="تگ‌ها">
                                  <div className="flex flex-wrap gap-1">
                                      {newTaskData.tags?.map(tag => (
                                          <span key={tag} className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-xs flex items-center gap-1">
                                              {tag} <X size={12} className="cursor-pointer hover:text-red-500" onClick={() => setNewTaskData({...newTaskData, tags: newTaskData.tags?.filter(t => t !== tag)})} />
                                          </span>
                                      ))}
                                      {showTagInput ? (
                                          <input autoFocus className="bg-slate-50 border border-slate-200 rounded px-2 py-0.5 text-xs w-20" 
                                            value={newTag} onChange={e => setNewTag(e.target.value)} onKeyDown={e => {if(e.key === 'Enter') handleAddTag(); if(e.key === 'Escape') setShowTagInput(false);}} onBlur={() => setShowTagInput(false)} />
                                      ) : (
                                          <button onClick={() => setShowTagInput(true)} className="text-slate-400 hover:text-blue-600 bg-slate-50 hover:bg-blue-50 px-2 py-0.5 rounded text-xs transition-colors">Add</button>
                                      )}
                                  </div>
                              </PropRow>
                          </div>
                      </div>
                      
                      {/* Dependencies Row (Full Width) */}
                      <div className="mb-6">
                           <div className="flex items-center gap-2 mb-2">
                               <PropRow icon={LinkIcon} label="وابستگی‌ها">
                                   <div className="relative">
                                       <div className="flex flex-wrap gap-2">
                                           {newTaskData.dependencies?.map(depId => {
                                               const depTask = tasks.find(t => t.id === depId);
                                               return depTask ? (
                                                  <div key={depId} className="flex items-center gap-1 bg-yellow-50 text-yellow-700 px-2 py-1 rounded text-xs border border-yellow-100">
                                                      <span className="truncate max-w-[100px]">{depTask.title}</span>
                                                      <X size={12} className="cursor-pointer hover:text-red-500" onClick={() => setNewTaskData({...newTaskData, dependencies: newTaskData.dependencies?.filter(id => id !== depId)})} />
                                                  </div>
                                               ) : null;
                                           })}
                                            <button onClick={() => setShowDependencyPicker(!showDependencyPicker)} className="text-slate-400 hover:text-blue-600 hover:bg-blue-50 p-1 rounded transition-colors flex items-center gap-1 text-xs">
                                                <Plus size={14} /> افزودن
                                            </button>
                                       </div>
                                       {showDependencyPicker && (
                                           <div className="absolute top-full right-0 mt-1 w-64 bg-white border border-slate-200 rounded-lg shadow-xl z-20 p-2 animate-in fade-in zoom-in-95 max-h-48 overflow-y-auto">
                                                <input className="w-full text-xs p-2 border-b mb-2 focus:outline-none" placeholder="جستجوی تسک..." autoFocus />
                                                {tasks.filter(t => t.id !== editingTaskId && !newTaskData.dependencies?.includes(t.id)).map(t => (
                                                    <div key={t.id} onClick={() => handleAddDependency(t.id)} className="p-2 hover:bg-slate-50 cursor-pointer text-xs rounded truncate">
                                                        #{t.id.slice(-4)} - {t.title}
                                                    </div>
                                                ))}
                                           </div>
                                       )}
                                   </div>
                               </PropRow>
                           </div>
                      </div>

                      {/* Custom Fields (Dynamic List - Integrated into Grid or below) */}
                      <div className="mb-6 border-t border-slate-100 pt-4">
                           <div className="flex items-center justify-between mb-2">
                                <h4 className="text-xs font-bold text-slate-500 uppercase">فیلدهای سفارشی</h4>
                                <div className="relative">
                                    <button onClick={() => setShowFieldPicker(!showFieldPicker)} className="text-slate-400 hover:text-blue-600 p-1 rounded"><Plus size={16} /></button>
                                    {showFieldPicker && (
                                        <div className="absolute top-full left-0 mt-1 w-48 bg-white border border-slate-200 rounded-lg shadow-xl z-20 p-1">
                                            {['text', 'number', 'date', 'checkbox'].map(type => (
                                                <button key={type} onClick={() => handleAddCustomFieldToTask(type as any, `New ${type}`)} className="w-full text-right px-3 py-2 hover:bg-slate-50 rounded text-sm text-slate-600 capitalize">
                                                    {type} Field
                                                </button>
                                            ))}
                                        </div>
                                    )}
                                </div>
                           </div>
                           <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-2">
                               {newTaskData.customFields?.map((field) => (
                                   <PropRow key={field.id} icon={Database} label={field.name}>
                                       <input className="bg-transparent border-b border-transparent hover:border-slate-200 focus:border-blue-400 focus:outline-none py-1 text-sm text-slate-800 w-full"
                                            placeholder="Empty" value={field.value?.toString() || ''}
                                            onChange={(e) => {
                                                const updated = newTaskData.customFields!.map(f => f.id === field.id ? {...f, value: e.target.value} : f);
                                                setNewTaskData({...newTaskData, customFields: updated});
                                            }}
                                       />
                                   </PropRow>
                               ))}
                           </div>
                      </div>

                      <div className="mb-10 group relative">
                          <textarea className="w-full min-h-[120px] p-4 bg-slate-50 rounded-xl border-none focus:ring-1 focus:ring-blue-200 text-slate-700 leading-relaxed resize-none text-base placeholder-slate-400"
                              placeholder="توضیحات تکمیلی..." value={newTaskData.description} onChange={e => setNewTaskData({...newTaskData, description: e.target.value})}></textarea>
                      </div>

                      {/* Subtasks */}
                      <div className="mb-10">
                          <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-2">
                              <h3 className="text-sm font-bold text-slate-700 flex items-center gap-2"><LayoutList size={16} /> زیرمجموعه کارها</h3>
                              <div className="flex items-center gap-2">
                                 <button onClick={handleAddSubtask} className="text-xs bg-slate-100 hover:bg-slate-200 text-slate-600 px-3 py-1.5 rounded-md transition-colors flex items-center gap-1"><Plus size={14} /> تسک جدید</button>
                              </div>
                          </div>
                          <div className="space-y-1">
                                {newTaskData.subtasks?.map(subtask => (
                                    <div key={subtask.id} onClick={() => handleOpenSubtask(subtask)} className="flex items-center px-3 py-2.5 bg-white border border-slate-200 rounded-lg hover:shadow-sm hover:border-blue-300 cursor-pointer transition-all group">
                                        <div className="flex-1 flex items-center gap-3">
                                            <div className={`w-4 h-4 border-2 rounded-full ${subtask.isCompleted ? 'bg-green-500 border-green-500' : 'border-slate-300'}`}></div>
                                            <span className={`text-sm ${subtask.isCompleted ? 'text-slate-400 line-through' : 'text-slate-700 font-medium'}`}>{subtask.title}</span>
                                        </div>
                                        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                                            <PersianDatePicker 
                                                value={subtask.startDate || ''} 
                                                onChange={(d) => updateSubtaskDate(subtask.id, 'startDate', d)}
                                                className="text-xs text-slate-400 hover:text-blue-600 px-2 py-1 rounded bg-transparent hover:bg-slate-50 min-w-0"
                                                label=""
                                            />
                                            <span className="text-slate-300 text-xs">→</span>
                                            <PersianDatePicker 
                                                value={subtask.dueDate || ''} 
                                                onChange={(d) => updateSubtaskDate(subtask.id, 'dueDate', d)}
                                                className="text-xs text-slate-400 hover:text-blue-600 px-2 py-1 rounded bg-transparent hover:bg-slate-50 min-w-0"
                                                label=""
                                            />
                                        </div>
                                    </div>
                                ))}
                                <div className="mt-3 flex items-center gap-2 opacity-60 focus-within:opacity-100 transition-opacity bg-white p-2 border border-dashed border-slate-300 rounded-lg">
                                    <Plus size={16} className="text-slate-400" />
                                    <input className="flex-1 bg-transparent border-none focus:ring-0 text-sm placeholder-slate-400" placeholder="افزودن سریع..." value={newSubtaskTitle} onChange={e => setNewSubtaskTitle(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleAddSubtask()} />
                                </div>
                          </div>
                      </div>
                  </div>
                  <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-3 sticky bottom-0">
                      <button onClick={handleSaveTask} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-medium shadow-sm transition-colors">{editingTaskId ? 'ذخیره تغییرات' : 'ایجاد وظیفه'}</button>
                  </div>
              </div>
              {/* Activity Log Sidebar (Simplified) */}
              <div className="w-full md:w-96 border-r border-slate-200 bg-slate-50 flex flex-col h-full">
                  <div className="p-4 border-b border-slate-200"><h3 className="font-bold text-slate-700 text-sm">فعالیت‌ها</h3></div>
                  <div className="flex-1 overflow-y-auto p-4 space-y-6">
                      {newTaskData.activityLog?.map(log => (
                          <div key={log.id} className="flex gap-3 text-xs"><div className="font-bold">{allUsers.find(u=>u.id===log.userId)?.name}</div><div>{log.details}</div></div>
                      ))}
                  </div>
                  <div className="p-4 bg-white border-t border-slate-200">
                      <div className="relative">
                          <textarea className="w-full border border-slate-300 rounded-xl p-3 text-sm h-20" placeholder="نظر دهید..." value={newComment} onChange={e => setNewComment(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendComment(); } }}></textarea>
                          <button className="absolute bottom-2 left-2 text-blue-600" onClick={handleSendComment}><Send size={14} className="rtl:rotate-180"/></button>
                      </div>
                  </div>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};