import React from 'react';
import { Mail, Send, Paperclip, Star, Trash2 } from 'lucide-react';
import { DataService } from '../services/dataService';

export const Messages: React.FC = () => {
  const messages = DataService.getMessages();
  const users = DataService.getUsers();

  return (
    <div className="flex h-[calc(100vh-64px)] bg-white">
      {/* Sidebar List */}
      <div className="w-80 border-l border-slate-200 flex flex-col">
        <div className="p-4 border-b border-slate-100">
          <button className="w-full bg-blue-600 text-white py-2.5 rounded-lg font-medium hover:bg-blue-700 transition-colors shadow-sm shadow-blue-200">
            پیام جدید
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">
          {messages.map(msg => {
            const sender = users.find(u => u.id === msg.senderId);
            return (
              <div key={msg.id} className={`p-4 border-b border-slate-50 hover:bg-slate-50 cursor-pointer transition-colors ${!msg.isRead ? 'bg-blue-50/50' : ''}`}>
                <div className="flex justify-between items-start mb-1">
                  <h4 className={`text-sm text-slate-800 ${!msg.isRead ? 'font-bold' : 'font-medium'}`}>{sender?.name || 'Unknown'}</h4>
                  <span className="text-xs text-slate-400">{msg.timestamp}</span>
                </div>
                <h5 className="text-sm text-slate-700 mb-1 truncate">{msg.subject}</h5>
                <p className="text-xs text-slate-500 truncate">{msg.content}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Message Content */}
      <div className="flex-1 flex flex-col bg-slate-50/30">
        {messages.length > 0 ? (
          <>
            {/* Toolbar */}
            <div className="h-16 border-b border-slate-200 bg-white flex items-center justify-between px-6">
               <div className="flex gap-2">
                 <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500"><Trash2 size={18} /></button>
                 <button className="p-2 hover:bg-slate-100 rounded-full text-slate-500"><Star size={18} /></button>
               </div>
               <div className="text-slate-400 text-sm">1 از {messages.length}</div>
            </div>

            {/* Content */}
            <div className="flex-1 p-8 overflow-y-auto">
              <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow-sm border border-slate-100 p-8">
                 <div className="flex justify-between items-start mb-8 pb-6 border-b border-slate-100">
                    <div className="flex gap-4">
                       <img src={users.find(u => u.id === messages[0].senderId)?.avatar} className="w-12 h-12 rounded-full" alt="avatar" />
                       <div>
                          <h2 className="text-xl font-bold text-slate-800 mb-1">{messages[0].subject}</h2>
                          <div className="flex gap-2 text-sm text-slate-500">
                             <span>از: <span className="text-slate-700 font-medium">{users.find(u => u.id === messages[0].senderId)?.name}</span></span>
                             <span>به: <span className="text-slate-700 font-medium">من</span></span>
                          </div>
                       </div>
                    </div>
                    <span className="text-sm text-slate-400">{messages[0].timestamp}</span>
                 </div>
                 
                 <div className="prose prose-slate max-w-none text-slate-600 leading-relaxed min-h-[200px]">
                    {messages[0].content}
                 </div>

                 {messages[0].hasAttachments && (
                   <div className="mt-8 pt-6 border-t border-slate-100">
                     <div className="inline-flex items-center gap-3 px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg">
                       <Paperclip size={16} className="text-slate-400" />
                       <span className="text-sm text-slate-700">Document.pdf</span>
                       <span className="text-xs text-slate-400">(2.4 MB)</span>
                     </div>
                   </div>
                 )}
              </div>
            </div>

            {/* Reply Area */}
            <div className="bg-white border-t border-slate-200 p-4">
               <div className="max-w-3xl mx-auto relative">
                  <textarea 
                    placeholder="پاسخ خود را بنویسید..." 
                    className="w-full border border-slate-300 rounded-xl p-4 pl-12 focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none resize-none h-24"
                  ></textarea>
                  <div className="absolute bottom-3 left-3 flex gap-2">
                     <button className="p-2 text-slate-400 hover:text-slate-600"><Paperclip size={20} /></button>
                     <button className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-lg transition-colors">
                        <Send size={18} className="rtl:rotate-180" />
                     </button>
                  </div>
               </div>
            </div>
          </>
        ) : (
          <div className="flex items-center justify-center h-full text-slate-400">پیامی وجود ندارد</div>
        )}
      </div>
    </div>
  );
};