
import React, { useState, useRef, useEffect } from 'react';
import { DataService } from '../services/dataService';
import { 
  Hash, Search, MoreVertical, Send, Paperclip, Phone, Video, 
  Info, Users, Smile, Lock, Plus, X, Mic, MicOff, VideoOff, 
  PhoneOff, Pin, FileText, Download, Trash2, Settings, UserPlus,
  Reply, Camera, CornerUpRight, LogOut, Edit3
} from 'lucide-react';
import { CURRENT_USER } from '../constants';
import { Channel, Message, User } from '../types';

export const Channels: React.FC = () => {
  const [channels, setChannels] = useState(DataService.getChannels());
  const allOrgUsers = DataService.getUsers();
  const [activeChannelId, setActiveChannelId] = useState(channels[0]?.id);
  const [messageInput, setMessageInput] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const channelAvatarRef = useRef<HTMLInputElement>(null);
  
  // Modals & UI States
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isCallActive, setIsCallActive] = useState<{ type: 'voice' | 'video'; active: boolean } | null>(null);
  const [settingsTab, setSettingsTab] = useState<'general' | 'members'>('general');
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);

  // New Channel Form State
  const [newChannelData, setNewChannelData] = useState({ name: '', isPrivate: false, members: [CURRENT_USER.id] });

  // Messages State (Managed locally for this demo)
  const [channelMessages, setChannelMessages] = useState<Message[]>([
      { id: 'cm1', channelId: 'c1', senderId: 'u2', content: 'سلام به همه، جلسه امروز ساعت ۱۰ برگزار میشه.', timestamp: '09:00', isRead: true, hasAttachments: false },
      { id: 'cm2', channelId: 'c1', senderId: 'u3', content: 'من کمی با تاخیر میرسم.', timestamp: '09:05', isRead: true, hasAttachments: false },
      { id: 'cm3', channelId: 'c1', senderId: 'u1', content: 'مشکلی نیست، صورت جلسه را بعدا مطالعه کنید.', timestamp: '09:10', isRead: true, hasAttachments: false },
      { id: 'cm4', channelId: 'c2', senderId: 'u1', content: 'تسک‌های اسپرینت جدید بررسی شد؟', timestamp: 'Yesterday', isRead: true, hasAttachments: false },
  ]);

  const activeChannel = channels.find(c => c.id === activeChannelId);
  const currentMessages = channelMessages.filter(m => m.channelId === activeChannelId);
  const pinnedMessages = currentMessages.filter(m => m.isPinned);

  const handleSendMessage = (e?: React.FormEvent, attachments?: any[]) => {
      if(e) e.preventDefault();
      if(!messageInput.trim() && (!attachments || attachments.length === 0)) return;
      
      const newMessage: Message = {
          id: `new-${Date.now()}`,
          channelId: activeChannelId,
          senderId: CURRENT_USER.id,
          content: messageInput,
          timestamp: new Date().toLocaleTimeString('fa-IR', {hour: '2-digit', minute:'2-digit'}),
          isRead: true,
          hasAttachments: !!(attachments && attachments.length > 0),
          attachments: attachments,
          replyToId: replyingTo?.id
      };
      
      setChannelMessages(prev => [...prev, newMessage]);
      setMessageInput('');
      setReplyingTo(null);
  };

  const handleCreateChannel = () => {
      if(!newChannelData.name.trim()) return;
      const newChannel: Channel = {
          id: `c-${Date.now()}`,
          name: newChannelData.name,
          isPrivate: newChannelData.isPrivate,
          members: newChannelData.members,
          avatar: 'https://picsum.photos/200/200?random=' + Date.now()
      };
      DataService.addChannel(newChannel);
      setChannels(prev => [...prev, newChannel]);
      setIsCreateModalOpen(false);
      setNewChannelData({ name: '', isPrivate: false, members: [CURRENT_USER.id] });
  };

  // Fixed Delete Message Logic
  const handleDeleteMessage = (msgId: string) => {
      if(window.confirm('آیا از حذف این پیام اطمینان دارید؟')) {
          setChannelMessages(prev => prev.filter(m => m.id !== msgId));
      }
  };

  const togglePinMessage = (msgId: string) => {
      setChannelMessages(prev => prev.map(m => m.id === msgId ? { ...m, isPinned: !m.isPinned } : m));
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const attachment = {
              name: file.name,
              size: (file.size / 1024).toFixed(1) + ' KB',
              type: file.type
          };
          handleSendMessage(undefined, [attachment]);
      }
  };

  const handleChannelAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file && activeChannel) {
          const reader = new FileReader();
          reader.onloadend = () => {
              const base64 = reader.result as string;
              const updated = { ...activeChannel, avatar: base64 };
              setChannels(prev => prev.map(c => c.id === activeChannelId ? updated : c));
              DataService.updateChannel(updated);
          };
          reader.readAsDataURL(file);
      }
  };

  // --- Channel Settings Handlers ---
  const handleUpdateChannelName = (name: string) => {
    if (!activeChannel) return;
    const updated = { ...activeChannel, name };
    setChannels(prev => prev.map(c => c.id === activeChannelId ? updated : c));
    DataService.updateChannel(updated);
  };

  const handleUpdateDescription = (description: string) => {
    if (!activeChannel) return;
    const updated = { ...activeChannel, description };
    setChannels(prev => prev.map(c => c.id === activeChannelId ? updated : c));
    DataService.updateChannel(updated);
  };

  const handleTogglePrivacy = () => {
    if (!activeChannel) return;
    const updated = { ...activeChannel, isPrivate: !activeChannel.isPrivate };
    setChannels(prev => prev.map(c => c.id === activeChannelId ? updated : c));
    DataService.updateChannel(updated);
  };

  const handleAddMember = (userId: string) => {
    if (!activeChannel) return;
    if (activeChannel.members.includes(userId)) return;
    const updated = { ...activeChannel, members: [...activeChannel.members, userId] };
    setChannels(prev => prev.map(c => c.id === activeChannelId ? updated : c));
    DataService.updateChannel(updated);
  };

  const handleRemoveMember = (userId: string) => {
    if (!activeChannel || userId === CURRENT_USER.id) return;
    const updated = { ...activeChannel, members: activeChannel.members.filter(id => id !== userId) };
    setChannels(prev => prev.map(c => c.id === activeChannelId ? updated : c));
    DataService.updateChannel(updated);
  };

  const handleDeleteChannel = () => {
    if (window.confirm('آیا از حذف کامل این کانال اطمینان دارید؟')) {
        const remaining = channels.filter(c => c.id !== activeChannelId);
        setChannels(remaining);
        setChannelMessages(prev => prev.filter(m => m.channelId !== activeChannelId));
        setActiveChannelId(remaining[0]?.id);
        setIsSettingsModalOpen(false);
    }
  };

  return (
    <div className="flex h-[calc(100vh-64px)] bg-white overflow-hidden relative">
      {/* Sidebar - Channel List */}
      <div className="w-64 bg-slate-50 border-l border-slate-200 flex flex-col shadow-inner">
        <div className="p-4 border-b border-slate-200 flex items-center justify-between">
           <h3 className="font-bold text-slate-700 text-sm">کانال‌ها</h3>
           <button onClick={() => setIsCreateModalOpen(true)} className="p-1.5 hover:bg-slate-200 rounded-lg text-blue-600 transition-all active:scale-95">
               <Plus size={18} />
           </button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-3 space-y-1 custom-scrollbar">
           {channels.map(channel => (
               <button 
                key={channel.id}
                onClick={() => setActiveChannelId(channel.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${activeChannelId === channel.id ? 'bg-blue-600 text-white shadow-lg shadow-blue-200 font-medium' : 'text-slate-600 hover:bg-slate-200/50'}`}
               >
                   <div className="relative flex-shrink-0">
                       {channel.avatar ? (
                           <img src={channel.avatar} className="w-8 h-8 rounded-lg object-cover" alt={channel.name} />
                       ) : (
                           <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${activeChannelId === channel.id ? 'bg-white/20' : 'bg-slate-200 text-slate-500'}`}>
                               {channel.isPrivate ? <Lock size={14} /> : <Hash size={16} />}
                           </div>
                       )}
                   </div>
                   <span className="truncate flex-1 text-right">{channel.name}</span>
               </button>
           ))}
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col min-w-0 bg-white">
          {/* Header */}
          <div className="h-16 border-b border-slate-200 flex items-center justify-between px-6 bg-white shadow-sm z-10">
              <div className="flex items-center gap-3 overflow-hidden">
                  {activeChannel?.avatar ? (
                      <img src={activeChannel.avatar} className="w-10 h-10 rounded-xl object-cover border border-slate-100" />
                  ) : (
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400">
                          {activeChannel?.isPrivate ? <Lock size={20} /> : <Hash size={24} />}
                      </div>
                  )}
                  <div className="flex flex-col">
                    <h2 className="font-bold text-slate-800 truncate leading-tight">{activeChannel?.name}</h2>
                    <p className="text-[10px] text-slate-400 font-medium">{activeChannel?.members.length} عضو</p>
                  </div>
              </div>
              <div className="flex items-center gap-1 text-slate-400">
                  <button onClick={() => setIsCallActive({type:'voice', active:true})} className="p-2.5 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all" title="تماس صوتی"><Phone size={20}/></button>
                  <button onClick={() => setIsCallActive({type:'video', active:true})} className="p-2.5 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all" title="تماس تصویری"><Video size={20}/></button>
                  <div className="w-px h-6 bg-slate-200 mx-2"></div>
                  <button onClick={() => setIsSettingsModalOpen(true)} className="p-2.5 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all" title="تنظیمات کانال"><Settings size={20}/></button>
              </div>
          </div>

          {/* Pinned Messages Bar */}
          {pinnedMessages.length > 0 && (
              <div className="bg-blue-50 px-4 py-2 border-b border-blue-100 flex items-center justify-between animate-in slide-in-from-top duration-300">
                  <div className="flex items-center gap-3 overflow-hidden">
                      <Pin size={14} className="text-blue-600 flex-shrink-0" />
                      <div className="text-xs text-blue-800 truncate">
                          <span className="font-bold ml-1">پین شده:</span>
                          {pinnedMessages[pinnedMessages.length - 1].content}
                      </div>
                  </div>
                  <button className="text-[10px] text-blue-600 font-bold hover:underline whitespace-nowrap">مشاهده همه</button>
              </div>
          )}

          {/* Messages Container */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/20 custom-scrollbar">
              {currentMessages.map((msg, index) => {
                  const isMe = msg.senderId === CURRENT_USER.id;
                  const sender = allOrgUsers.find(u => u.id === msg.senderId);
                  const isSequence = index > 0 && currentMessages[index-1].senderId === msg.senderId;
                  const repliedMsg = msg.replyToId ? channelMessages.find(m => m.id === msg.replyToId) : null;
                  const repliedSender = repliedMsg ? allOrgUsers.find(u => u.id === repliedMsg.senderId) : null;

                  return (
                      <div key={msg.id} className={`flex gap-3 group animate-in fade-in slide-in-from-bottom-2 duration-300 ${isMe ? 'flex-row-reverse' : ''} ${isSequence ? 'mt-0.5' : 'mt-4'}`}>
                          {!isSequence ? (
                              <img src={sender?.avatar} className="w-10 h-10 rounded-xl object-cover shadow-sm border border-white" alt={sender?.name} />
                          ) : <div className="w-10 flex-shrink-0"></div>}
                          
                          <div className={`max-w-[75%] ${isMe ? 'items-end text-right' : 'items-start text-right'} flex flex-col relative`}>
                              {!isSequence && !isMe && <span className="text-xs text-slate-500 mb-1 font-medium mr-1">{sender?.name}</span>}
                              
                              <div className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed shadow-sm transition-all group-hover:shadow-md ${
                                  isMe 
                                  ? 'bg-blue-600 text-white rounded-tl-none' 
                                  : 'bg-white text-slate-800 border border-slate-200 rounded-tr-none'
                              } ${msg.isPinned ? 'ring-2 ring-blue-300 ring-offset-2' : ''}`}>
                                  
                                  {/* Reply Preview inside Message Bubble */}
                                  {repliedMsg && (
                                      <div className={`mb-2 p-2 rounded-lg text-xs border-r-4 opacity-80 ${isMe ? 'bg-blue-700/50 border-blue-300' : 'bg-slate-100 border-slate-400'}`}>
                                          <div className="font-bold mb-0.5">{repliedSender?.name}</div>
                                          <div className="truncate italic">{repliedMsg.content}</div>
                                      </div>
                                  )}

                                  <div className="whitespace-pre-wrap">{msg.content}</div>
                                  
                                  {/* Attachments UI */}
                                  {msg.attachments?.map((file, fidx) => (
                                      <div key={fidx} className={`mt-2 flex items-center gap-3 p-2 rounded-xl border ${isMe ? 'bg-blue-700/50 border-blue-500' : 'bg-slate-50 border-slate-200'}`}>
                                          <div className={`p-2 rounded-lg ${isMe ? 'bg-blue-800/40' : 'bg-white shadow-sm'}`}><FileText size={18} className={isMe ? 'text-blue-100' : 'text-slate-400'} /></div>
                                          <div className="flex-1 overflow-hidden text-right">
                                              <div className={`text-xs font-bold truncate ${isMe ? 'text-white' : 'text-slate-700'}`}>{file.name}</div>
                                              <div className={`text-[10px] ${isMe ? 'text-blue-200' : 'text-slate-400'}`}>{file.size}</div>
                                          </div>
                                          <button className={`p-1.5 rounded-lg hover:bg-black/10 transition-colors ${isMe ? 'text-white' : 'text-blue-600'}`}><Download size={14}/></button>
                                      </div>
                                  ))}
                              </div>

                              <div className={`flex items-center gap-2 mt-1 mx-1 ${isMe ? 'flex-row-reverse' : ''}`}>
                                  <span className="text-[10px] text-slate-400 font-mono opacity-80">{msg.timestamp}</span>
                                  {msg.isPinned && <Pin size={10} className="text-blue-500" />}
                              </div>

                              {/* Message Actions - Floating Menu */}
                              <div className={`absolute top-0 ${isMe ? 'right-full mr-2' : 'left-full ml-2'} opacity-0 group-hover:opacity-100 transition-all flex items-center bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden z-20`}>
                                  <button onClick={() => setReplyingTo(msg)} className="p-2 hover:bg-blue-50 text-slate-500 hover:text-blue-600 transition-colors" title="پاسخ">
                                      <Reply size={16} className="rtl:rotate-180" />
                                  </button>
                                  <button onClick={() => togglePinMessage(msg.id)} className="p-2 hover:bg-blue-50 text-slate-500 hover:text-blue-600 transition-colors" title={msg.isPinned ? "آن‌پین" : "پین کردن"}>
                                      <Pin size={16} className={msg.isPinned ? 'fill-blue-600 text-blue-600' : ''} />
                                  </button>
                                  <button onClick={() => handleDeleteMessage(msg.id)} className="p-2 hover:bg-red-50 text-slate-500 hover:text-red-600 transition-colors" title="حذف پیام">
                                      <Trash2 size={16}/>
                                  </button>
                              </div>
                          </div>
                      </div>
                  )
              })}
          </div>

          {/* Chat Input Bar */}
          <div className="p-4 bg-white border-t border-slate-200">
              {/* Active Reply Banner */}
              {replyingTo && (
                  <div className="max-w-4xl mx-auto mb-2 flex items-center justify-between bg-slate-50 border border-slate-200 p-2 px-4 rounded-xl animate-in slide-in-from-bottom-2">
                      <div className="flex items-center gap-3 overflow-hidden">
                          <CornerUpRight size={16} className="text-blue-500 flex-shrink-0" />
                          <div className="text-xs truncate text-right">
                              <span className="font-bold text-slate-700">پاسخ به {allOrgUsers.find(u => u.id === replyingTo.senderId)?.name}:</span>
                              <span className="text-slate-500 mr-2 italic">"{replyingTo.content}"</span>
                          </div>
                      </div>
                      <button onClick={() => setReplyingTo(null)} className="text-slate-400 hover:text-red-500 p-1 transition-colors"><X size={16}/></button>
                  </div>
              )}

              <form onSubmit={handleSendMessage} className="relative max-w-4xl mx-auto bg-slate-100/80 rounded-2xl border border-slate-200 focus-within:border-blue-400 focus-within:ring-4 focus-within:ring-blue-100 focus-within:bg-white transition-all flex items-end p-2 shadow-sm">
                  <input type="file" ref={fileInputRef} className="hidden" onChange={handleFileUpload} />
                  <button type="button" onClick={() => fileInputRef.current?.click()} className="p-2.5 text-slate-400 hover:text-blue-600 hover:bg-slate-200 rounded-xl transition-colors" title="ارسال فایل"><Paperclip size={20}/></button>
                  <textarea 
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    onKeyDown={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSendMessage(e);
                        }
                    }}
                    placeholder={`پیام به #${activeChannel?.name}...`}
                    className="flex-1 bg-transparent border-none focus:ring-0 resize-none max-h-48 min-h-[44px] py-2.5 px-3 text-sm custom-scrollbar text-right"
                    rows={1}
                  />
                  <button type="button" className="p-2.5 text-slate-400 hover:text-blue-600 hover:bg-slate-200 rounded-xl transition-colors"><Smile size={20}/></button>
                  <button type="submit" className={`p-2.5 rounded-xl transition-all active:scale-95 ${messageInput.trim() ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' : 'bg-slate-200 text-slate-400'}`}>
                      <Send size={20} className="rtl:rotate-180" />
                  </button>
              </form>
          </div>
      </div>

      {/* --- MODALS --- */}

      {/* Advanced Channel Settings & Profile Image Modal */}
      {isSettingsModalOpen && activeChannel && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[60] flex items-center justify-center p-4 animate-in fade-in">
              <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[90vh]">
                  <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                      <div className="flex items-center gap-4">
                          <div className="relative group flex-shrink-0">
                              <img src={activeChannel.avatar || 'https://via.placeholder.com/150'} className="w-16 h-16 rounded-2xl object-cover border-4 border-white shadow-md transition-all group-hover:brightness-75" />
                              <button onClick={() => channelAvatarRef.current?.click()} className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 text-white transition-opacity bg-black/20 rounded-2xl" title="تغییر تصویر پروفایل">
                                <Camera size={24}/>
                              </button>
                              <input type="file" ref={channelAvatarRef} className="hidden" accept="image/*" onChange={handleChannelAvatarUpload} />
                          </div>
                          <div className="text-right">
                              <h2 className="text-2xl font-black text-slate-800">{activeChannel.name}</h2>
                              <p className="text-xs text-slate-500 font-medium">مدیریت کانال و دسترسی‌ها</p>
                          </div>
                      </div>
                      <button onClick={() => setIsSettingsModalOpen(false)} className="p-3 hover:bg-slate-200 rounded-full transition-colors"><X/></button>
                  </div>
                  
                  {/* Settings Tabs */}
                  <div className="flex border-b border-slate-100 px-8 bg-white sticky top-0">
                      <button onClick={() => setSettingsTab('general')} className={`px-6 py-4 text-sm font-bold border-b-4 transition-all ${settingsTab === 'general' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>اطلاعات کلی</button>
                      <button onClick={() => setSettingsTab('members')} className={`px-6 py-4 text-sm font-bold border-b-4 transition-all ${settingsTab === 'members' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}>مدیریت اعضا ({activeChannel.members.length})</button>
                  </div>

                  <div className="p-8 overflow-y-auto custom-scrollbar flex-1 bg-slate-50/30">
                      {settingsTab === 'general' ? (
                          <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
                              <div className="space-y-3">
                                  <label className="block text-xs font-black text-slate-500 uppercase tracking-widest text-right">نام کانال</label>
                                  <div className="relative">
                                    <input 
                                        className="w-full border-2 border-slate-100 bg-white rounded-2xl p-4 text-lg font-bold text-slate-800 focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all text-right shadow-sm"
                                        defaultValue={activeChannel.name}
                                        placeholder="مثلا: تیم توسعه"
                                        onBlur={(e) => handleUpdateChannelName(e.target.value)}
                                    />
                                    <Edit3 size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" />
                                  </div>
                              </div>

                              <div className="space-y-3">
                                  <label className="block text-xs font-black text-slate-500 uppercase tracking-widest text-right">توضیحات کانال</label>
                                  <textarea 
                                      className="w-full border-2 border-slate-100 bg-white rounded-2xl p-4 text-sm text-slate-700 focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all text-right shadow-sm min-h-[100px] resize-none"
                                      defaultValue={activeChannel.description || ''}
                                      placeholder="موضوع فعالیت این کانال چیست؟"
                                      onBlur={(e) => handleUpdateDescription(e.target.value)}
                                  />
                              </div>
                              
                              <div className="flex items-center justify-between p-5 bg-white rounded-2xl border-2 border-slate-100 shadow-sm">
                                  <div className="flex items-center gap-4 text-right">
                                      <div className={`p-3 rounded-2xl flex-shrink-0 ${activeChannel.isPrivate ? 'bg-orange-100 text-orange-600' : 'bg-blue-100 text-blue-600'}`}>
                                          {activeChannel.isPrivate ? <Lock size={24} /> : <Hash size={24} />}
                                      </div>
                                      <div>
                                          <div className="text-base font-black text-slate-800">کانال خصوصی</div>
                                          <div className="text-xs text-slate-500 mt-1 font-medium">فقط اعضای تایید شده امکان مشاهده پیام‌ها را دارند.</div>
                                      </div>
                                  </div>
                                  <button 
                                      onClick={handleTogglePrivacy}
                                      className={`w-14 h-7 rounded-full transition-all relative flex-shrink-0 ${activeChannel.isPrivate ? 'bg-blue-600' : 'bg-slate-300'}`}
                                  >
                                      <div className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow-md transition-all ${activeChannel.isPrivate ? 'left-1' : 'left-8'}`}></div>
                                  </button>
                              </div>

                              <div className="pt-8 border-t border-slate-200">
                                  <div className="p-6 bg-red-50 rounded-2xl border border-red-100">
                                      <h4 className="text-sm font-black text-red-700 mb-2 flex items-center gap-2 justify-end"><Trash2 size={16}/> منطقه خطر</h4>
                                      <p className="text-xs text-red-600/80 mb-5 leading-relaxed font-medium text-right">با حذف این کانال، تمام پیام‌ها، فایل‌ها و تنظیمات آن به صورت دائمی حذف شده و قابل بازیابی نخواهد بود.</p>
                                      <div className="flex justify-end">
                                        <button onClick={handleDeleteChannel} className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl font-bold shadow-lg shadow-red-200 transition-all flex items-center gap-2 active:scale-95">
                                            حذف کامل این کانال
                                        </button>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      ) : (
                          <div className="space-y-8 animate-in slide-in-from-left-4 duration-300">
                              {/* Add Member UI */}
                              <div className="bg-blue-600 p-6 rounded-3xl shadow-xl shadow-blue-200 text-white">
                                  <label className="block text-xs font-black text-blue-100 uppercase mb-4 tracking-widest text-right">افزودن عضو جدید</label>
                                  <div className="space-y-2 max-h-48 overflow-y-auto pr-2 custom-scrollbar rtl">
                                      {allOrgUsers.filter(u => !activeChannel.members.includes(u.id)).map(user => (
                                          <div key={user.id} className="flex items-center justify-between bg-white/10 p-3 rounded-2xl backdrop-blur-md border border-white/20 hover:bg-white/20 transition-all">
                                              <div className="flex items-center gap-3">
                                                  <img src={user.avatar} className="w-10 h-10 rounded-xl object-cover border border-white/30" />
                                                  <span className="text-sm font-bold">{user.name}</span>
                                              </div>
                                              <button onClick={() => handleAddMember(user.id)} className="p-2 bg-white text-blue-600 rounded-xl transition-all hover:scale-110 active:scale-90 shadow-lg shadow-blue-900/20">
                                                  <UserPlus size={18} />
                                              </button>
                                          </div>
                                      ))}
                                      {allOrgUsers.filter(u => !activeChannel.members.includes(u.id)).length === 0 && (
                                          <p className="text-xs text-blue-100/60 text-center py-4 italic font-medium">تمام کاربران سازمان عضو این کانال هستند.</p>
                                      )}
                                  </div>
                              </div>

                              {/* Current Members Listing */}
                              <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
                                  <label className="block text-xs font-black text-slate-500 uppercase mb-4 tracking-widest text-right">اعضای فعلی ({activeChannel.members.length})</label>
                                  <div className="divide-y divide-slate-100">
                                      {activeChannel.members.map(memberId => {
                                          const user = allOrgUsers.find(u => u.id === memberId);
                                          if (!user) return null;
                                          return (
                                              <div key={user.id} className="flex items-center justify-between py-4 group">
                                                  <div className="flex items-center gap-4 text-right">
                                                      <div className="relative">
                                                          <img src={user.avatar} className="w-11 h-11 rounded-xl border border-slate-100 object-cover shadow-sm" />
                                                          <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>
                                                      </div>
                                                      <div>
                                                          <div className="text-sm font-black text-slate-800">{user.name} {user.id === CURRENT_USER.id && <span className="text-blue-600 mr-1 text-[10px] bg-blue-50 px-1.5 py-0.5 rounded">شما</span>}</div>
                                                          <div className="text-[10px] text-slate-400 font-bold uppercase">{user.role}</div>
                                                      </div>
                                                  </div>
                                                  {user.id !== CURRENT_USER.id && (
                                                      <button onClick={() => handleRemoveMember(user.id)} className="p-2 text-slate-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100" title="اخراج از کانال">
                                                          <Trash2 size={18} />
                                                      </button>
                                                  )}
                                              </div>
                                          )
                                      })}
                                  </div>
                              </div>
                          </div>
                      )}
                  </div>
                  <div className="p-6 bg-slate-50 border-t border-slate-100 flex justify-end gap-3 shadow-inner">
                      <button className="flex items-center gap-2 px-5 py-3 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-2xl font-bold transition-all text-sm">
                        <LogOut size={18}/> ترک کانال
                      </button>
                      <button onClick={() => setIsSettingsModalOpen(false)} className="px-10 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-black shadow-xl transition-all active:scale-95">تایید و بازگشت</button>
                  </div>
              </div>
          </div>
      )}

      {/* Basic Create Channel Modal */}
      {isCreateModalOpen && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[60] flex items-center justify-center p-4 animate-in fade-in">
              <div className="bg-white rounded-[32px] w-full max-w-md shadow-2xl overflow-hidden border border-slate-100">
                  <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                      <h2 className="text-2xl font-black text-slate-800">ایجاد کانال جدید</h2>
                      <button onClick={() => setIsCreateModalOpen(false)} className="p-2.5 hover:bg-slate-200 rounded-full transition-colors"><X/></button>
                  </div>
                  <div className="p-8 space-y-6">
                      <div className="space-y-2">
                          <label className="block text-xs font-black text-slate-500 uppercase tracking-widest text-right">نام کانال</label>
                          <input 
                            className="w-full border-2 border-slate-100 bg-white rounded-2xl p-4 font-bold text-slate-800 focus:ring-4 focus:ring-blue-100 focus:border-blue-500 outline-none transition-all text-right"
                            placeholder="مثلا: تیم گرافیک"
                            value={newChannelData.name}
                            onChange={e => setNewChannelData({...newChannelData, name: e.target.value})}
                          />
                      </div>
                      <div className="flex items-center justify-between p-5 bg-blue-50 rounded-3xl border-2 border-blue-100">
                          <div className="text-right">
                              <div className="text-base font-black text-blue-800 flex items-center gap-2 justify-end">
                                  <Lock size={18} />
                                  خصوصی‌سازی
                              </div>
                              <div className="text-[10px] text-blue-600 mt-1 font-bold">فقط اعضا اجازه دسترسی دارند.</div>
                          </div>
                          <button 
                            onClick={() => setNewChannelData({...newChannelData, isPrivate: !newChannelData.isPrivate})}
                            className={`w-14 h-7 rounded-full transition-all relative ${newChannelData.isPrivate ? 'bg-blue-600' : 'bg-slate-300'}`}
                          >
                              <div className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow-md transition-all ${newChannelData.isPrivate ? 'left-1' : 'left-8'}`}></div>
                          </button>
                      </div>
                  </div>
                  <div className="p-8 bg-slate-50 flex flex-col gap-3 border-t border-slate-100">
                      <button onClick={handleCreateChannel} className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black shadow-xl shadow-blue-200 transition-all active:scale-95">ساخت کانال</button>
                      <button onClick={() => setIsCreateModalOpen(false)} className="w-full py-3 text-slate-400 font-bold hover:text-slate-600 transition-colors">انصراف</button>
                  </div>
              </div>
          </div>
      )}

      {/* Call UI Overlay */}
      {isCallActive && (
          <div className="fixed inset-0 bg-slate-900/98 z-[100] flex flex-col items-center justify-center p-8 animate-in zoom-in-95 duration-300 backdrop-blur-lg">
              <div className="relative mb-10">
                  <div className="absolute inset-0 rounded-full border-8 border-blue-500/30 animate-ping duration-[2000ms]"></div>
                  <img src={activeChannel?.avatar || 'https://picsum.photos/400/400'} className="w-56 h-56 rounded-[48px] border-4 border-blue-600 p-2 object-cover shadow-2xl relative z-10" />
                  <div className="absolute -bottom-2 -right-2 bg-blue-600 p-4 rounded-3xl text-white shadow-xl">
                      {isCallActive.type === 'voice' ? <Phone size={32} /> : <Video size={32} />}
                  </div>
              </div>
              <h2 className="text-4xl font-black text-white mb-3">{isCallActive.type === 'voice' ? 'تماس صوتی' : 'تماس تصویری'}</h2>
              <p className="text-blue-400 text-lg mb-16 font-black tracking-widest uppercase">{activeChannel?.name}</p>
              
              <div className="flex items-center gap-10">
                  <button className="w-20 h-20 bg-white/10 hover:bg-white/20 text-white rounded-[32px] flex items-center justify-center shadow-xl backdrop-blur-md transition-all active:scale-90 border border-white/10"><MicOff size={32}/></button>
                  <button onClick={() => setIsCallActive(null)} className="w-24 h-24 bg-red-600 hover:bg-red-700 text-white rounded-[40px] flex items-center justify-center shadow-2xl shadow-red-900/50 transition-all active:scale-90 animate-bounce"><PhoneOff size={40}/></button>
                  <button className="w-20 h-20 bg-white/10 hover:bg-white/20 text-white rounded-[32px] flex items-center justify-center shadow-xl backdrop-blur-md transition-all active:scale-90 border border-white/10"><VideoOff size={32}/></button>
              </div>
          </div>
      )}
    </div>
  );
};
