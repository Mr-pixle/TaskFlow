import React, { useState } from 'react';
import { DataService } from '../services/dataService';
import { Note } from '../types';
import { Plus, X, Save, Clock, Edit3 } from 'lucide-react';
import { PersianDatePicker } from '../components/PersianDatePicker';

export const Notes: React.FC = () => {
  const [notes, setNotes] = useState(DataService.getNotes());
  const [editingNote, setEditingNote] = useState<Partial<Note> | null>(null);

  const handleSaveNote = () => {
      if(!editingNote?.title || !editingNote?.content) return;
      
      if (editingNote.id) {
          // Update
          const updated = { ...editingNote, updatedAt: new Date().toLocaleDateString('fa-IR') } as Note;
          setNotes(notes.map(n => n.id === updated.id ? updated : n));
      } else {
          // Create
          const newNote: Note = {
              id: `n-${Date.now()}`,
              title: editingNote.title,
              content: editingNote.content,
              updatedAt: new Date().toLocaleDateString('fa-IR')
          };
          const added = DataService.addNote(newNote);
          setNotes([...notes, added]);
      }
      setEditingNote(null);
  };

  const colors = ['bg-yellow-100', 'bg-blue-100', 'bg-green-100', 'bg-pink-100', 'bg-purple-100', 'bg-orange-100'];

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold text-slate-800">یادداشت‌ها</h1>
          <p className="text-slate-500 mt-1">ایده‌ها و نوشته‌های شخصی شما</p>
        </div>
        <button onClick={() => setEditingNote({ title: '', content: '' })} className="bg-slate-800 hover:bg-slate-900 text-white px-5 py-2.5 rounded-xl shadow-lg transition-all flex items-center gap-2">
            <Plus size={20} /> یادداشت جدید
        </button>
      </div>

      <div className="columns-1 md:columns-2 lg:columns-3 gap-6 space-y-6">
          {notes.map((note, idx) => (
              <div 
                key={note.id} 
                onClick={() => setEditingNote(note)}
                className={`break-inside-avoid rounded-2xl p-6 shadow-sm hover:shadow-md transition-all cursor-pointer border border-transparent hover:border-black/5 group relative ${colors[idx % colors.length]}`}
              >
                  <h3 className="font-bold text-lg text-slate-800 mb-3">{note.title}</h3>
                  <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap">{note.content}</p>
                  
                  <div className="mt-4 pt-4 border-t border-black/5 flex justify-between items-center text-xs opacity-60">
                      <div className="flex items-center gap-1">
                          <Clock size={12} />
                          {note.updatedAt}
                      </div>
                      <Edit3 size={14} className="opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
              </div>
          ))}
          
          {/* Add card placeholder */}
          <button onClick={() => setEditingNote({ title: '', content: '' })} className="w-full h-48 border-2 border-dashed border-slate-300 rounded-2xl flex flex-col items-center justify-center text-slate-400 hover:border-blue-400 hover:text-blue-500 transition-colors bg-slate-50 hover:bg-blue-50/30">
              <Plus size={32} className="mb-2" />
              <span>افزودن یادداشت سریع</span>
          </button>
      </div>

      {editingNote && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in">
              <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
                  <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                      <input 
                        className="bg-transparent text-xl font-bold text-slate-800 placeholder-slate-400 focus:outline-none w-full"
                        placeholder="عنوان یادداشت..."
                        value={editingNote.title}
                        onChange={e => setEditingNote({...editingNote, title: e.target.value})}
                        autoFocus
                      />
                      <button onClick={() => setEditingNote(null)} className="p-2 hover:bg-slate-200 rounded-full text-slate-500"><X size={20}/></button>
                  </div>
                  <div className="flex-1 p-6 overflow-y-auto">
                      <textarea 
                        className="w-full h-full min-h-[300px] resize-none focus:outline-none text-slate-700 leading-loose text-lg placeholder-slate-300"
                        placeholder="شروع به نوشتن کنید..."
                        value={editingNote.content}
                        onChange={e => setEditingNote({...editingNote, content: e.target.value})}
                      />
                  </div>
                  <div className="p-4 border-t border-slate-100 flex justify-end gap-3 bg-slate-50">
                      <span className="text-xs text-slate-400 self-center flex-1 mr-2">آخرین تغییر: {new Date().toLocaleDateString('fa-IR')}</span>
                      <button onClick={handleSaveNote} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-xl font-medium shadow-sm flex items-center gap-2">
                          <Save size={18} /> ذخیره
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};