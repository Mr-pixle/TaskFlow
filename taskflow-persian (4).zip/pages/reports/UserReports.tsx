import React from 'react';
import { DataService } from '../../services/dataService';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { User } from '../../types';

export const UserReports: React.FC = () => {
  const users = DataService.getUsers();
  const tasks = DataService.getTasks();

  // Process data
  const userStats = users.map(user => {
      const userTasks = tasks.filter(t => t.assignees.includes(user.id));
      const done = userTasks.filter(t => t.status === 'Done').length;
      const progress = userTasks.filter(t => t.status === 'In Progress').length;
      const todo = userTasks.filter(t => t.status === 'Todo').length;
      const overdue = userTasks.filter(t => t.status !== 'Done' && new Date(t.dueDate || '') < new Date()).length;
      
      return {
          name: user.name,
          total: userTasks.length,
          Done: done,
          InProgress: progress,
          Todo: todo,
          Overdue: overdue,
          score: done * 10 + progress * 5 // Arbitrary productivity score
      };
  });

  const COLORS = ['#10b981', '#3b82f6', '#94a3b8', '#ef4444'];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-800">گزارش عملکرد اعضا</h1>
        <p className="text-slate-500 mt-1">تحلیل آماری وظایف و بهره‌وری تیم</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="text-slate-500 text-sm font-medium mb-2">پرکارترین عضو</div>
              <div className="text-xl font-bold text-slate-800">{userStats.sort((a,b) => b.total - a.total)[0]?.name}</div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="text-slate-500 text-sm font-medium mb-2">بیشترین تاخیر</div>
              <div className="text-xl font-bold text-red-600">{userStats.sort((a,b) => b.Overdue - a.Overdue)[0]?.name}</div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="text-slate-500 text-sm font-medium mb-2">مجموع وظایف</div>
              <div className="text-xl font-bold text-blue-600">{tasks.length}</div>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
              <div className="text-slate-500 text-sm font-medium mb-2">میانگین تکمیل</div>
              <div className="text-xl font-bold text-green-600">
                  {Math.round((tasks.filter(t=>t.status==='Done').length / tasks.length) * 100)}%
              </div>
          </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Main Bar Chart */}
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 h-[400px]">
              <h3 className="font-bold text-slate-700 mb-6">توزیع وظایف بر اساس کاربر</h3>
              <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={userStats} layout="vertical" margin={{top: 5, right: 30, left: 20, bottom: 5}}>
                      <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                      <XAxis type="number" />
                      <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
                      <Tooltip cursor={{fill: 'transparent'}} />
                      <Legend />
                      <Bar dataKey="Done" name="انجام شده" stackId="a" fill="#10b981" barSize={20} radius={[0, 4, 4, 0]} />
                      <Bar dataKey="InProgress" name="در حال انجام" stackId="a" fill="#3b82f6" />
                      <Bar dataKey="Todo" name="انجام نشده" stackId="a" fill="#e2e8f0" radius={[4, 0, 0, 4]} />
                  </BarChart>
              </ResponsiveContainer>
          </div>

           {/* Overdue Chart */}
           <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 h-[400px]">
              <h3 className="font-bold text-slate-700 mb-6">وظایف تاخیر خورده</h3>
              <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={userStats}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" tick={{fontSize: 12}} />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="Overdue" name="تاخیر" fill="#ef4444" radius={[4, 4, 0, 0]} barSize={40} />
                  </BarChart>
              </ResponsiveContainer>
          </div>
      </div>

      {/* Detailed Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          <table className="w-full">
              <thead className="bg-slate-50 border-b border-slate-200">
                  <tr>
                      <th className="px-6 py-4 text-right text-sm font-semibold text-slate-600">نام کاربر</th>
                      <th className="px-6 py-4 text-center text-sm font-semibold text-slate-600">کل وظایف</th>
                      <th className="px-6 py-4 text-center text-sm font-semibold text-green-600">انجام شده</th>
                      <th className="px-6 py-4 text-center text-sm font-semibold text-blue-600">در حال انجام</th>
                      <th className="px-6 py-4 text-center text-sm font-semibold text-red-600">تاخیر</th>
                      <th className="px-6 py-4 text-center text-sm font-semibold text-slate-600">امتیاز</th>
                  </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                  {userStats.map((stat, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50">
                          <td className="px-6 py-4 font-medium text-slate-800">{stat.name}</td>
                          <td className="px-6 py-4 text-center text-slate-600">{stat.total}</td>
                          <td className="px-6 py-4 text-center font-bold text-green-600">{stat.Done}</td>
                          <td className="px-6 py-4 text-center text-blue-600">{stat.InProgress}</td>
                          <td className="px-6 py-4 text-center font-bold text-red-500">{stat.Overdue}</td>
                          <td className="px-6 py-4 text-center">
                              <span className="bg-slate-100 px-2 py-1 rounded text-xs font-mono">{stat.score}</span>
                          </td>
                      </tr>
                  ))}
              </tbody>
          </table>
      </div>
    </div>
  );
};