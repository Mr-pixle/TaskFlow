import React from 'react';
import { DataService } from '../../services/dataService';
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from 'recharts';
import { CheckCircle2, Circle, Clock, AlertTriangle } from 'lucide-react';

export const ProjectReports: React.FC = () => {
  const projects = DataService.getProjects();
  const tasks = DataService.getTasks();

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-slate-800">گزارش وضعیت پروژه‌ها</h1>
        <p className="text-slate-500 mt-1">نمای کلی از پیشرفت و سلامت پروژه‌های جاری</p>
      </div>

      <div className="space-y-8">
          {projects.map(project => {
              const projectTasks = tasks.filter(t => t.projectId === project.id);
              const total = projectTasks.length;
              const done = projectTasks.filter(t => t.status === 'Done').length;
              const inProgress = projectTasks.filter(t => t.status === 'In Progress').length;
              const todo = projectTasks.filter(t => t.status === 'Todo').length;
              const progress = total === 0 ? 0 : Math.round((done / total) * 100);

              const data = [
                  { name: 'انجام شده', value: done, color: '#10b981' },
                  { name: 'در حال انجام', value: inProgress, color: '#3b82f6' },
                  { name: 'باقی‌مانده', value: todo, color: '#e2e8f0' },
              ];

              return (
                  <div key={project.id} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 flex flex-col md:flex-row gap-8">
                      {/* Left: Info & Progress */}
                      <div className="flex-1">
                          <div className="flex justify-between items-start mb-4">
                              <div>
                                  <span className="text-xs font-mono text-slate-400 bg-slate-100 px-2 py-0.5 rounded mb-2 inline-block">{project.code}</span>
                                  <h2 className="text-xl font-bold text-slate-800">{project.name}</h2>
                                  <p className="text-sm text-slate-500 mt-1">مدت پروژه: {project.startDate} تا {project.endDate}</p>
                              </div>
                              <div className="text-right">
                                  <div className="text-3xl font-bold text-blue-600">{progress}%</div>
                                  <div className="text-xs text-slate-400">پیشرفت کل</div>
                              </div>
                          </div>

                          {/* Progress Bar */}
                          <div className="w-full bg-slate-100 rounded-full h-3 mb-6 overflow-hidden">
                              <div className="bg-blue-600 h-3 rounded-full transition-all duration-1000" style={{width: `${progress}%`}}></div>
                          </div>

                          <div className="grid grid-cols-3 gap-4">
                              <div className="bg-green-50 rounded-xl p-3 flex items-center gap-3">
                                  <div className="p-2 bg-white rounded-full text-green-600 shadow-sm"><CheckCircle2 size={16}/></div>
                                  <div>
                                      <div className="text-lg font-bold text-green-700">{done}</div>
                                      <div className="text-xs text-green-600">تکمیل شده</div>
                                  </div>
                              </div>
                              <div className="bg-blue-50 rounded-xl p-3 flex items-center gap-3">
                                  <div className="p-2 bg-white rounded-full text-blue-600 shadow-sm"><Clock size={16}/></div>
                                  <div>
                                      <div className="text-lg font-bold text-blue-700">{inProgress}</div>
                                      <div className="text-xs text-blue-600">در جریان</div>
                                  </div>
                              </div>
                              <div className="bg-slate-50 rounded-xl p-3 flex items-center gap-3">
                                  <div className="p-2 bg-white rounded-full text-slate-500 shadow-sm"><Circle size={16}/></div>
                                  <div>
                                      <div className="text-lg font-bold text-slate-700">{todo}</div>
                                      <div className="text-xs text-slate-500">انجام نشده</div>
                                  </div>
                              </div>
                          </div>
                      </div>

                      {/* Right: Chart */}
                      <div className="w-full md:w-64 h-48 relative">
                          <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                  <Pie
                                      data={data}
                                      cx="50%"
                                      cy="50%"
                                      innerRadius={40}
                                      outerRadius={60}
                                      paddingAngle={5}
                                      dataKey="value"
                                      stroke="none"
                                  >
                                      {data.map((entry, index) => (
                                          <Cell key={`cell-${index}`} fill={entry.color} />
                                      ))}
                                  </Pie>
                                  <Tooltip />
                              </PieChart>
                          </ResponsiveContainer>
                          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                              <div className="text-center">
                                  <div className="text-xs text-slate-400">وظایف</div>
                                  <div className="font-bold text-slate-700">{total}</div>
                              </div>
                          </div>
                      </div>
                  </div>
              )
          })}
      </div>
    </div>
  );
};